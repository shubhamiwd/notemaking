<?php 
/*
Template Name: Extra Fields.
*/
?>

								<!----------Hidden_Fields---------->
								<ul class="rbtn hidden_infltration tabcls" style="display:none;">
									<li>
										<input type='radio' id="Buccal" name='Infilteration' data-fieddata="Patient" value='--> Buccal'>
										<label for="Buccal">Buccal</label>
									</li>
									<li>
										<input type='radio' id="Palatal" name='Infilteration' data-fieddata="Patient" value='--> Palatal'>
										<label for="Palatal">Palatal</label>
									</li>
									<li>
										<input type='radio' id="Lingual" name='Infilteration' data-fieddata="Patient" value='--> Lingual'>
										<label for="Lingual">Lingual</label>
									</li>
									<li>
										<input type='radio' id="B_P" name='Infilteration' data-fieddata="Patient" value='--> B+P'>
										<label for="B_P">B+P</label>
									</li>
									<li>
										<input type='radio' id="B_L" name='Infilteration' data-fieddata="Patient" value='--> B+L'>
										<label for="B_L">B+L</label>
									</li>
								</ul>
								
								<ul class="rbtn hidden_infltration tabcls" style="display:none;">
									<li>
										<input type='radio' id="Articaine" name='Infilteration_two' data-fieddata="Patient" value='--> Articaine 4% 1:200,000 epinephrine'>
										<label for="Articaine">Articaine 4% 1:200,000 epinephrine</label>
									</li>
									<li>
										<input type='radio' id="Lidocaine" name='Infilteration_two' data-fieddata="Patient" value='--> Lidocaine 2% 1:80,000 epinephrine'>
										<label for="Lidocaine">Lidocaine 2% 1:80,000 epinephrine</label>
									</li>
									<li>
										<input type='radio' id="Mepivicaine" name='Infilteration_two' data-fieddata="Patient" value='--> Mepivicaine 3%'>
										<label for="Mepivicaine">Mepivicaine 3%</label>
									</li>
									<li>
										<input type='radio' id="other_one" name='Infilteration_two' data-fieddata="Patient" value='--> Other'>
										<label for="other_one">Other</label>
									</li>
								</ul>
								
								<ul class="rbtn hidden_infltration tabcls" style="display:none;">
									<li>
										<input type='radio' id="0_2" name='Infilteration_three' data-fieddata="Patient" value='--> 0.2'>
										<label for="0_2">0.2</label>
									</li>
									<li>
										<input type='radio' id="0_5" name='Infilteration_three' data-fieddata="Patient" value='--> 0.5'>
										<label for="0_5">0.5</label>
									</li>
									<li>
										<input type='radio' id="1_0" name='Infilteration_three' data-fieddata="Patient" value='--> 1.0'>
										<label for="1_0">1.0</label>
									</li>
									<li>
										<input type='radio' id="1_2" name='Infilteration_three' data-fieddata="Patient" value='--> 1.2'>
										<label for="1_2">1.2</label>
									</li>
									<li>
										<input type='radio' id="1_5" name='Infilteration_three' data-fieddata="Patient" value='--> 1.5'>
										<label for="1_5">1.5</label>
									</li>
									<li>
										<input type='radio' id="2_2" name='Infilteration_three' data-fieddata="Patient" value='--> 2.2'>
										<label for="2_2">2.2</label>
									</li>
									<li>
										<input type='radio' id="other_two" name='Infilteration_three' data-fieddata="Patient" value='--> Other'>
										<label for="other_two">Other</label>
									</li>
								</ul>
							  <!------->

							    <ul class="rbtn hidden_IANB tabcls" style="display:none;">
									<li>
										<input type='radio' id="ianb_rhs" name='ianb_rhslhs' data-fieddata="Patient" value='--> RHS'>
										<label for="ianb_rhs">RHS</label>
									</li>
									<li>
										<input type='radio' id="ianb_lhs" name='ianb_rhslhs' data-fieddata="Patient" value='--> LHS'>
										<label for="ianb_lhs">LHS</label>
									</li>
								</ul>	
							  
							  <ul class="rbtn hidden_IANB tabcls" style="display:none;">
									<li>
										<input type='radio' id="ianb_one" name='Infilteration_two' data-fieddata="Patient" value='--> Articaine 4% 1:200,000 epinephrine'>
										<label for="ianb_one">Articaine 4% 1:200,000 epinephrine</label>
									</li>
									<li>
										<input type='radio' id="ianb_two" name='Infilteration_two' data-fieddata="Patient" value='--> Lidocaine 2% 1:80,000 epinephrine'>
										<label for="ianb_two">Lidocaine 2% 1:80,000 epinephrine</label>
									</li>
									<li>
										<input type='radio' id="ianb_three" name='Infilteration_two' data-fieddata="Patient" value='--> Mepivicaine 3%'>
										<label for="ianb_three">Mepivicaine 3%</label>
									</li>
									<li>
										<input type='radio' id="ianb_other" name='Infilteration_two' data-fieddata="Patient" value='--> Other'>
										<label for="ianb_other">Other</label>
									</li>
								</ul>
							  
							  <ul class="rbtn hidden_IANB tabcls" style="display:none;">
									<li>
										<input type='radio' id="ianb_0_2" name='Infilteration_three' data-fieddata="Patient" value='--> 0.2'>
										<label for="ianb_0_2">0.2</label>
									</li>
									<li>
										<input type='radio' id="ianb_0_5" name='Infilteration_three' data-fieddata="Patient" value='--> 0.5'>
										<label for="ianb_0_5">0.5</label>
									</li>
									<li>
										<input type='radio' id="ianb_1_0" name='Infilteration_three' data-fieddata="Patient" value='--> 1.0'>
										<label for="ianb_1_0">1.0</label>
									</li>
									<li>
										<input type='radio' id="ianb_1_2" name='Infilteration_three' data-fieddata="Patient" value='--> 1.2'>
										<label for="ianb_1_2">1.2</label>
									</li>
									<li>
										<input type='radio' id="ianb_1_5" name='Infilteration_three' data-fieddata="Patient" value='--> 1.5'>
										<label for="ianb_1_5">1.5</label>
									</li>
									<li>
										<input type='radio' id="ianb_2_2" name='Infilteration_three' data-fieddata="Patient" value='--> 2.2'>
										<label for="ianb_2_2">2.2</label>
									</li>
									<li>
										<input type='radio' id="ianb_other_two" name='Infilteration_three' data-fieddata="Patient" value='--> Other'>
										<label for="ianb_other_two">Other</label>
									</li>
								</ul>
								
							  <!---------------->
							  
							  <ul class="rbtn hidden_IANB_Infiltration tabcls" style="display:none;">
									<li>
										<input type='radio' id="IANB_Infiltration_rhs" name='ianb_rhslhs' data-fieddata="Patient" value='--> RHS'>
										<label for="IANB_Infiltration_rhs">RHS</label>
									</li>
									<li>
										<input type='radio' id="IANB_Infiltration_lhs" name='ianb_rhslhs' data-fieddata="Patient" value='--> LHS'>
										<label for="IANB_Infiltration_lhs">LHS</label>
									</li>
							  </ul>	
							  
							  <ul class="rbtn hidden_IANB_Infiltration tabcls" style="display:none;">
									<li>
										<input type='radio' id="IANB_Infiltration_one" name='Infilteration_two' data-fieddata="Patient" value='--> Articaine 4% 1:200,000 epinephrine'>
										<label for="IANB_Infiltration_one">Articaine 4% 1:200,000 epinephrine</label>
									</li>
									<li>
										<input type='radio' id="IANB_Infiltration_two" name='Infilteration_two' data-fieddata="Patient" value='--> Lidocaine 2% 1:80,000 epinephrine'>
										<label for="IANB_Infiltration_two">Lidocaine 2% 1:80,000 epinephrine</label>
									</li>
									<li>
										<input type='radio' id="IANB_Infiltration_three" name='Infilteration_two' data-fieddata="Patient" value='--> Mepivicaine 3%'>
										<label for="IANB_Infiltration_three">Mepivicaine 3%</label>
									</li>
									<li>
										<input type='radio' id="IANB_Infiltration_other" name='Infilteration_two' data-fieddata="Patient" value='--> Other'>
										<label for="IANB_Infiltration_other">Other</label>
									</li>
								</ul>
							  
							  <ul class="rbtn hidden_IANB_Infiltration tabcls" style="display:none;">
									<li>
										<input type='radio' id="IANB_Infiltration_0_2" name='Infilteration_three' data-fieddata="Patient" value='--> 0.2'>
										<label for="IANB_Infiltration_0_2">0.2</label>
									</li>
									<li>
										<input type='radio' id="IANB_Infiltration_0_5" name='Infilteration_three' data-fieddata="Patient" value='--> 0.5'>
										<label for="IANB_Infiltration_0_5">0.5</label>
									</li>
									<li>
										<input type='radio' id="IANB_Infiltration_1_0" name='Infilteration_three' data-fieddata="Patient" value='--> 1.0'>
										<label for="IANB_Infiltration_1_0">1.0</label>
									</li>
									<li>
										<input type='radio' id="IANB_Infiltration_1_2" name='Infilteration_three' data-fieddata="Patient" value='--> 1.2'>
										<label for="IANB_Infiltration_1_2">1.2</label>
									</li>
									<li>
										<input type='radio' id="IANB_Infiltration_1_5" name='Infilteration_three' data-fieddata="Patient" value='--> 1.5'>
										<label for="IANB_Infiltration_1_5">1.5</label>
									</li>
									<li>
										<input type='radio' id="IANB_Infiltration_2_2" name='Infilteration_three' data-fieddata="Patient" value='--> 2.2'>
										<label for="IANB_Infiltration_2_2">2.2</label>
									</li>
									<li>
										<input type='radio' id="IANB_Infiltration_other_two" name='Infilteration_three' data-fieddata="Patient" value='--> Other'>
										<label for="IANB_Infiltration_other_two">Other</label>
									</li>
								</ul>
								
								<ul class="rbtn hidden_IANB_Infiltration tabcls" style="display:none;">
									<li>
										<input type='radio' id="IANB_Infiltration_Buccal" name='Infilteration' data-fieddata="Patient" value='--> Buccal'>
										<label for="IANB_Infiltration_Buccal">Buccal</label>
									</li>
									<li>
										<input type='radio' id="IANB_Infiltration_Palatal" name='Infilteration' data-fieddata="Patient" value='--> Palatal'>
										<label for="IANB_Infiltration_Palatal">Palatal</label>
									</li>
									<li>
										<input type='radio' id="IANB_Infiltration_Lingual" name='Infilteration' data-fieddata="Patient" value='--> Lingual'>
										<label for="IANB_Infiltration_Lingual">Lingual</label>
									</li>
									<li>
										<input type='radio' id="IANB_Infiltration_B_P" name='Infilteration' data-fieddata="Patient" value='--> B+P'>
										<label for="IANB_Infiltration_B_P">B+P</label>
									</li>
									<li>
										<input type='radio' id="IANB_Infiltration_B_L" name='Infilteration' data-fieddata="Patient" value='--> B+L'>
										<label for="IANB_Infiltration_B_L">B+L</label>
									</li>
								</ul>
							  
							  	<ul class="rbtn hidden_IANB_Infiltration tabcls" style="display:none;">
									<li>
										<input type='radio' id="IANB_Infiltration_Articaine" name='Infilteration_two_2' data-fieddata="Patient" value='--> Articaine 4% 1:200,000 epinephrine'>
										<label for="IANB_Infiltration_Articaine">Articaine 4% 1:200,000 epinephrine</label>
									</li>
									<li>
										<input type='radio' id="IANB_Infiltration_Lidocaine" name='Infilteration_two_2' data-fieddata="Patient" value='--> Lidocaine 2% 1:80,000 epinephrine'>
										<label for="IANB_Infiltration_Lidocaine">Lidocaine 2% 1:80,000 epinephrine</label>
									</li>
									<li>
										<input type='radio' id="IANB_Infiltration_Mepivicaine" name='Infilteration_two_2' data-fieddata="Patient" value='--> Mepivicaine 3%'>
										<label for="IANB_Infiltration_Mepivicaine">Mepivicaine 3%</label>
									</li>
									<li>
										<input type='radio' id="IANB_Infiltration_other_last" name='Infilteration_two_2' data-fieddata="Patient" value='--> Other'>
										<label for="IANB_Infiltration_other_last">Other</label>
									</li>
								</ul>
							  
								<ul class="rbtn hidden_IANB_Infiltration tabcls" style="display:none;">
									<li>
										<input type='radio' id="IANB_Infiltration_0_2_2n" name='Infilteration_three_2' data-fieddata="Patient" value='--> 0.2'>
										<label for="IANB_Infiltration_0_2_2n">0.2</label>
									</li>
									<li>
										<input type='radio' id="IANB_Infiltration_0_5_2n" name='Infilteration_three_2' data-fieddata="Patient" value='--> 0.5'>
										<label for="IANB_Infiltration_0_5_2n">0.5</label>
									</li>
									<li>
										<input type='radio' id="IANB_Infiltration_1_0_2n" name='Infilteration_three_2' data-fieddata="Patient" value='--> 1.0'>
										<label for="IANB_Infiltration_1_0_2n">1.0</label>
									</li>
									<li>
										<input type='radio' id="IANB_Infiltration_1_2_2n" name='Infilteration_three_2' data-fieddata="Patient" value='--> 1.2'>
										<label for="IANB_Infiltration_1_2_2n">1.2</label>
									</li>
									<li>
										<input type='radio' id="IANB_Infiltration_1_5_2n" name='Infilteration_three_2' data-fieddata="Patient" value='--> 1.5'>
										<label for="IANB_Infiltration_1_5_2n">1.5</label>
									</li>
									<li>
										<input type='radio' id="IANB_Infiltration_2_2_2n" name='Infilteration_three_2' data-fieddata="Patient" value='--> 2.2'>
										<label for="IANB_Infiltration_2_2_2n">2.2</label>
									</li>
									<li>
										<input type='radio' id="IANB_Infiltration_other_two_2n" name='Infilteration_three_2' data-fieddata="Patient" value='--> Other'>
										<label for="IANB_Infiltration_other_two_2n">Other</label>
									</li>
								</ul>
							  