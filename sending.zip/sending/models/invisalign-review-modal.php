<!--------Modal_1 -------->

<div class="modal fade" id="myModal_1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header allmodalheading">
		<h5>Select Teeth</h5>
       <!-- <button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
      </div>
      <div class="modal-body">
        <!--<div class="row">
          <div class="col-md-12">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<input type='checkbox' id="Uppers" class="irm_tth_fn" data-sectionId="teeth_sel" name="dental_exam_caries" value='Uppers'>
					<label for="Uppers">Uppers</label>
				</li>
			</ul>	
          </div>
        </div>-->
        <div class="row">
          <!--<div class="col-md-1">
			<ul class="modal-ch">
				<li class="modal_li_full strighttext">
		          	<input type='checkbox' id="rhs" class="irm_tth_fn" data-sectionId="teeth_sel" name="dental_exam_caries" value='RHS'>
					<label for="rhs">R<br>H<br>S</label>
				</li>
			</ul>	
          </div>-->
          <div class="col-md-6 border_rightonepx">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="urq" class="irm_tth_fn" data-sectionId="teeth_sel" name="dental_exam_caries" value='URQ'>-->
					<label for="urq">Upper Right</label>
				</li>
			</ul>
	        <div class="row">
	          <div class="col-md-12 border_bottomonepx">
				<ul class="modal-ch urq mb0" style="text-align: right;">
					<li class="">
			          	<input type='checkbox' id="irm_tth_18" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='18'>
						<label for="irm_tth_18">18</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="irm_tth_17" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='17'>
						<label for="irm_tth_17">17</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="irm_tth_16" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='16'>
						<label for="irm_tth_16">16</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="irm_tth_15" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='15'>
						<label for="irm_tth_15">15</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="irm_tth_14" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='14'>
						<label for="irm_tth_14">14</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="irm_tth_13" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='13'>
						<label for="irm_tth_13">13</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="irm_tth_12" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='12'>
						<label for="irm_tth_12">12</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="irm_tth_11" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='11'>
						<label for="irm_tth_11">11</label>
					</li>
				</ul>
	          </div>
          	</div>
          	<div class="seprater"> </div>
	        <div class="row">
	          <div class="col-md-12">
				<ul class="modal-ch urq mb0" style="text-align: right;">
					<li class="">
						<input type='checkbox' id="irm_tth_48" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='48'>
						<label for="irm_tth_48">48</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="irm_tth_47" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='47'>
						<label for="irm_tth_47">47</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="irm_tth_46" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='46'>
						<label for="irm_tth_46">46</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="irm_tth_45" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='45'>
						<label for="irm_tth_45">45</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="irm_tth_44" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='44'>
						<label for="irm_tth_44">44</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="irm_tth_43" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='43'>
						<label for="irm_tth_43">43</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="irm_tth_42" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='42'>
						<label for="irm_tth_42">42</label>
					</li><li class="">
			          	<input type='checkbox' id="irm_tth_41" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='41'>
						<label for="irm_tth_41">41</label>
					</li>

				</ul>
	          </div>
          	</div>	
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="LRQ" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='LRQ'>-->
					<label for="ULQ">Lower Right</label>
				</li>
			</ul>
          </div>
          <div class="col-md-6">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="ULQ" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='ULQ'>-->
					<label for="ULQ">Upper Left</label>
				</li>
			</ul>
	        <div class="row">
	          <div class="col-md-12 border_bottomonepx">
				<ul class="modal-ch urq mb0" style="text-align: left;">
					<li class="">
						<input type='checkbox' id="irm_tth_21" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='21'>
						<label for="irm_tth_21">21</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="irm_tth_22" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='22'>
						<label for="irm_tth_22">22</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="irm_tth_23" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='23'>
						<label for="irm_tth_23">23</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="irm_tth_24" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='24'>
						<label for="irm_tth_24">24</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="irm_tth_25" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='25'>
						<label for="irm_tth_25">25</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="irm_tth_26" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='26'>
						<label for="irm_tth_26">26</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="irm_tth_27" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='27'>
						<label for="irm_tth_27">27</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="irm_tth_28" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='28'>
						<label for="irm_tth_28">28</label>
					</li>
				</ul>
	          </div>
          	</div>	
          	<div class="seprater"> </div>
	        <div class="row">
	          <div class="col-md-12">
				<ul class="modal-ch urq mb0" style="text-align: left;">
					<li class="">
						<input type='checkbox' id="irm_tth_31" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='31'>
						<label for="irm_tth_31">31</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="irm_tth_32" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='32'>
						<label for="irm_tth_32">32</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="irm_tth_33" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='33'>
						<label for="irm_tth_33">33</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="irm_tth_34" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='34'>
						<label for="irm_tth_34">34</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="irm_tth_35" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='35'>
						<label for="irm_tth_35">35</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="irm_tth_36" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='36'>
						<label for="irm_tth_36">36</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="irm_tth_37" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='37'>
						<label for="irm_tth_37">37</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="irm_tth_38" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='38'>
						<label for="irm_tth_38">38</label>
					</li>
				</ul>
	          </div>
          	</div>	
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="LLQ" class="irm_tth_fn" data-sectionId="teeth_sel" name="dental_exam_caries" value='LLQ'>-->
					<label for="LLQ">Lower Left</label>
				</li>
			</ul>
          </div>
         <!-- <div class="col-md-1">
			<ul class="modal-ch">
				<li class="modal_li_full strighttext">
		          	<input type='checkbox' id="lhs" class="irm_tth_fn" data-sectionId="teeth_sel" value='LHS'>
					<label for="lhs">L<br>H<br>S</label>
				</li>
			</ul>	
          </div>-->
        </div>
        <!--<div class="row">
          <div class="col-md-12">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<input type='checkbox' id="Lowers" class="irm_tth_fn" data-sectionId="teeth_sel" name="dental_exam_caries" value='Lowers'>
					<label for="Lowers">Lowers</label>
				</li>
			</ul>	
          </div>
        </div>-->
      </div>
      <div class="modal-footer">
	 
	 <button type="button" class="btn cp_cl closebtn each_model_data" id="" data-teethname="IPR" data-spancls="ipr_teeth" data-checkedvalid="ipr_teeth_h" data-clicked_1="co_option_sel" data-fieldname="irm_tth" data-dismiss="modal" aria-label="Close">Add Note</button>
     
	 </div>
    </div>
  </div>
</div>
