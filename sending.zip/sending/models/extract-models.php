		<!--------Modal_1 -------->

						
<div class="modal fade" id="extract_modal_1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header allmodalheading">
		<h5>Patient attending for extraction : Select Teeth</h5>
       <!-- <button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
      </div>
      <div class="modal-body">
        <!---<div class="row">
          <div class="col-md-12">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<input type='checkbox' id="Uppers" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='Uppers'>
					<label for="Uppers">Uppers</label>
				</li>
			</ul>	
          </div>
        </div>--->
        <div class="row">
         <!-- <div class="col-md-1">
			<ul class="modal-ch">
				<li class="modal_li_full strighttext">
		          	<input type='checkbox' id="rhs" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='RHS'>
					<label for="rhs">R<br>H<br>S</label>
				</li>
			</ul>	
          </div>-->
          <div class="col-md-6 border_rightonepx">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="urq" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='URQ'>-->
			<label for="extract_max_urq">Upper Right</label>
				</li>
			</ul>
	        <div class="row">
	          <div class="col-md-12 border_bottomonepx">
				<ul class="modal-ch urq mb0" style="text-align: right;">
					<li class="">
			          	<input type='checkbox' id="extract_18" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='18'>
						<label for="extract_18">18</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="extract_17" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='17'>
						<label for="extract_17">17</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="extract_16" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='16'>
						<label for="extract_16">16</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="extract_15" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='15'>
						<label for="extract_15">15</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="extract_14" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='14'>
						<label for="extract_14">14</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="extract_13" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='13'>
						<label for="extract_13">13</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="extract_12" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='12'>
						<label for="extract_12">12</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="extract_11" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='11'>
						<label for="extract_11">11</label>
					</li>
				</ul>
	          </div>
          	</div>
          	<div class="seprater"> </div>
	        <div class="row">
	          <div class="col-md-12">
				<ul class="modal-ch urq mb0" style="text-align: right;">
					<li class="">
						<input type='checkbox' id="extract_48" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='48'>
						<label for="extract_48">48</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="extract_47" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='47'>
						<label for="extract_47">47</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="extract_46" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='46'>
						<label for="extract_46">46</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="extract_45" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='45'>
						<label for="extract_45">45</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="extract_44" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='44'>
						<label for="extract_44">44</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="extract_43" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='43'>
						<label for="extract_43">43</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="extract_42" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='42'>
						<label for="extract_42">42</label>
					</li><li class="">
			          	<input type='checkbox' id="extract_41" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='41'>
						<label for="extract_41">41</label>
					</li>
				</ul>
	          </div>
          	</div>
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="extract_max_LRQ" name="extract_max" class="te_clcik" data-sectionId="extract_sel" value='LRQ'>-->
					<label for="extract_max_LRQ">Lower Right</label>
				</li>
			</ul>
          </div>
          <div class="col-md-6">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="extract_max_ULQ" name="extract_max" class="te_clcik" data-sectionId="extract_sel" value='ULQ'>-->
					<label for="extract_max_ULQ">Upper Left</label>
				</li>
			</ul>
	        <div class="row">
	          <div class="col-md-12 border_bottomonepx">
				<ul class="modal-ch urq mb0" style="text-align: left;">
					<li class="">
						<input type='checkbox' id="extract_21" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='21'>
						<label for="extract_21">21</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="extract_22" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='22'>
						<label for="extract_22">22</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="extract_23" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='23'>
						<label for="extract_23">23</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="extract_24" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='24'>
						<label for="extract_24">24</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="extract_25" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='25'>
						<label for="extract_25">25</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="extract_26" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='26'>
						<label for="extract_26">26</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="extract_27" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='27'>
						<label for="extract_27">27</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="extract_28" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='28'>
						<label for="extract_28">28</label>
					</li>
				</ul>
	          </div>
          	</div>	
          	<div class="seprater"> </div>
	        <div class="row">
	          <div class="col-md-12">
				<ul class="modal-ch urq mb0" style="text-align: left;">
					<li class="">
						<input type='checkbox' id="extract_31" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='31'>
						<label for="extract_31">31</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="extract_32" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='32'>
						<label for="extract_32">32</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="extract_33" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='33'>
						<label for="extract_33">33</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="extract_34" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='34'>
						<label for="extract_34">34</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="extract_35" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='35'>
						<label for="extract_35">35</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="extract_36" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='36'>
						<label for="extract_36">36</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="extract_37" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='37'>
						<label for="extract_37">37</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="extract_38" class="te_clcik" data-sectionId="extract_sel" name="extract_max" value='38'>
						<label for="extract_38">38</label>
					</li>
				</ul>
	          </div>
          	</div>	
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="extract_max_LLQ" name="extract_max" class="te_clcik" data-sectionId="extract_sel" value='LLQ'>-->
					<label for="extract_max_LLQ">Lower Left</label>
				</li>
			</ul>
          </div>
          <!--<div class="col-md-1">
			<ul class="modal-ch">
				<li class="modal_li_full strighttext">
		          	<input type='checkbox' id="extract_max_lhs" name="extract_max" class="te_clcik" data-sectionId="extract_sel" value='LHS'>
					<label for="extract_max_lhs">L<br>H<br>S</label>
				</li>
			</ul>	
          </div>-->
        </div>
       <!-- <div class="row">
          <div class="col-md-12">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<input type='checkbox' id="extract_max_Lowers" name="extract_max" class="te_clcik" data-sectionId="extract_sel" value='Lowers'>
					<label for="extract_max_Lowers">Lowers</label>
				</li>
			</ul>	
          </div>
        </div>-->
      </div>
      <div class="modal-footer">
	  <button type="button" class="btn cp_cl closebtn each_model_data" id="" data-extractname="extract" data-teethname="Patient attending for extraction of" data-spancls="extraction_attending" data-checkedvalid="extract_teeth" data-clicked_1="co_option_sel" data-fieldname="extract_max" data-dismiss="modal" aria-label="Close">Add Note</button>
	
       <!--<button type="button" class="btn cp_cl closebtn" id="add_val_2" data-clicked="add_extract" data-dismiss="modal" aria-label="Close">Add Note</button>-->
	   <!--<button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
		<!--<div id="add_val" class="btn cp_cl close">Add</div>-->
      </div>
    </div>
  </div>
</div>

<!----------Modal 2--------->

	<div class="modal fade" id="extract_modal_2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header allmodalheading">
		<h5>Reason for XLA</h5>
       <!-- <button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
      </div>
      <div class="modal-body">
        <div class="row">
       
         <div class="col-md-12">
	        <div class="row">
	         
				<ul class="modal-ch urq" style="text-align: center;">
				<p>Select one or more notes to insert.</p>
					<li class="">
			          	<input type='checkbox' id="xla-reasons_1" class="xla-reasons_select" data-sectionId="extract_sel" name="xla-reasons_select" value='Gross caries'>
						<label for="xla-reasons_1">Gross caries</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="xla-reasons_2" class="xla-reasons_select" data-sectionId="extract_sel" name="xla-reasons_select" value='Periodontitis'>
						<label for="xla-reasons_2">Periodontitis</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="xla-reasons_3" class="xla-reasons_select" data-sectionId="extract_sel" name="xla-reasons_select" value='Irreversible pulpitis'>
						<label for="xla-reasons_3">Irreversible pulpitis</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="xla-reasons_4" class="xla-reasons_select" data-sectionId="extract_sel" name="xla-reasons_select" value='Failed RCT'>
						<label for="xla-reasons_4">Failed RCT</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="xla-reasons_5" class="xla-reasons_select" data-sectionId="extract_sel" name="xla-reasons_select" value='Elective'>
						<label for="xla-reasons_5">Elective</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="xla-reasons_6" class="xla-reasons_select" data-sectionId="extract_sel" name="xla-reasons_select" value='Request from Orthodontist'>
						<label for="xla-reasons_6">Request from Orthodontist</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="xla-reasons_7" class="xla-reasons_select" data-sectionId="extract_sel" name="xla-reasons_select" value='Other'>
						<label for="xla-reasons_7">Other</label>
					</li>
				</ul>
         	</div>	
          </div>
        </div>

      </div>
      <div class="modal-footer">
       <button type="button" class="btn cp_cl closebtn each_model_data" data-extractname="xla-reasons" data-teethname="Reason for XLA" data-spancls="select_xla-reasons" data-checkedvalid="extract_xla-reasons" data-clicked_1="co_option_sel" data-fieldname="xla-reasons_select" data-dismiss="modal" aria-label="Close">Add Note</button>
	   
	   <!--<button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
		<!--<div id="add_val" class="btn cp_cl close">Add</div>-->
      </div>
    </div>
  </div>
</div> 

<!-----------Alternative options--------->

	<div class="modal fade" id="extract_modal_3" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header allmodalheading">
		<h5>Alternative Options</h5>
       <!-- <button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
      </div>
      <div class="modal-body">
        <div class="row">
       
         <div class="col-md-12">
	        <div class="row">
	         
				<ul class="modal-ch urq" style="text-align: center;">
				<p>Select one or more notes to insert.</p>
					<li class="">
			          	<input type='checkbox' id="alternative_1" class="alternative_select" data-sectionId="extract_sel" name="alternative_select" value='Leave and monitor'>
						<label for="alternative_1">Leave and monitor</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="alternative_2" class="alternative_select" data-sectionId="extract_sel" name="alternative_select" value='RCT+Crown'>
						<label for="alternative_2">RCT+Crown</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="alternative_3" class="alternative_select" data-sectionId="extract_sel" name="alternative_select" value='Extirpate and temporise'>
						<label for="alternative_3">Extirpate and temporise</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="alternative_4" class="alternative_select" data-sectionId="extract_sel" name="alternative_select" value='Referral to specialist'>
						<label for="alternative_4">Referral to specialist</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="alternative_5" class="alternative_select" data-sectionId="extract_sel" name="alternative_select" value='Other'>
						<label for="alternative_5">Other</label>
					</li>
					</ul>
         	</div>	
          </div>
        </div>

      </div>
      <div class="modal-footer">
       <button type="button" class="btn cp_cl closebtn each_model_data" data-extractname="alternative-options" data-teethname="Alternative options" data-spancls="select_alternative_options" data-checkedvalid="extract_alternative_options" data-clicked_1="co_option_sel" data-fieldname="alternative_select" data-dismiss="modal" aria-label="Close">Add Note</button>
	   <!--<button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
		<!--<div id="add_val" class="btn cp_cl close">Add</div>-->
      </div>
    </div>
  </div>
</div> 

<!-----------Risks given:--------->

  <div class="modal fade" id="extract_modal_4" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header allmodalheading">
		<h5>Risks given: Pain, Bruising, Swelling, Bleeding,</h5>
       <!-- <button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
      </div>
      <div class="modal-body">
        <div class="row">
       
         <div class="col-md-12">
	        <div class="row">
	         
				<ul class="modal-ch urq" style="text-align: center;">
				<p>Select one or more notes to insert.</p>
					<li class="">
			          	<input type='checkbox' id="risk_given_1" class="risk_given_select" data-sectionId="extract_sel" name="risk_given_select" value='Other'>
						<label for="risk_given_1">Other</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="risk_given_2" class="risk_given_select" data-sectionId="extract_sel" name="risk_given_select" value='Fractured tooth needing referral to OS department'>
						<label for="risk_given_2">Fractured tooth needing referral to OS department</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="risk_given_3" class="risk_given_select" data-sectionId="extract_sel" name="risk_given_select" value='Damage to IANB'>
						<label for="risk_given_3">Damage to IANB</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="risk_given_4" class="risk_given_select" data-sectionId="extract_sel" name="risk_given_select" value='OAC'>
						<label for="risk_given_4">OAC</label>
					</li>
					</ul>
         	</div>	
          </div>
        </div>

      </div>
      <div class="modal-footer">
       <button type="button" class="btn cp_cl closebtn each_model_data" data-extractname="risk_given-options" data-teethname="Risk-Given" data-spancls="select_risk_given_options" data-checkedvalid="extract_risk_given_options" data-clicked_1="co_option_sel" data-fieldname="risk_given_select" data-dismiss="modal" aria-label="Close">Add Note</button>
	   <!--<button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
		<!--<div id="add_val" class="btn cp_cl close">Add</div>-->
      </div>
    </div>
  </div>
</div> 

<!-----------XLA completed with:--------->

  <div class="modal fade" id="extract_modal_5" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header allmodalheading">
		<h5>XLA completed with</h5>
       <!-- <button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
      </div>
      <div class="modal-body">
        <div class="row">
       
         <div class="col-md-12">
	        <div class="row">
	         
				<ul class="modal-ch urq" style="text-align: center;">
				<p>Select one or more notes to insert.</p>
					<li class="">
			          	<input type='checkbox' id="xla-completed_1" class="xla-completed_select" data-sectionId="extract_sel" name="xla-completed_select" value='Luxator'>
						<label for="xla-completed_1">Luxator</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="xla-completed_2" class="xla-completed_select" data-sectionId="extract_sel" name="xla-completed_select" value='Elevator'>
						<label for="xla-completed_2">Elevator</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="xla-completed_3" class="xla-completed_select" data-sectionId="extract_sel" name="xla-completed_select" value='Forceps'>
						<label for="xla-completed_3">Forceps</label>
					</li>
					</ul>
         	</div>	
          </div>
        </div>

      </div>
      <div class="modal-footer">
       <button type="button" class="btn cp_cl closebtn each_model_data" data-extractname="xla-completed-options" data-teethname="XLA completed with" data-spancls="select_xla-completed_options" data-checkedvalid="extract_xla-completed_options" data-clicked_1="co_option_sel" data-fieldname="xla-completed_select" data-dismiss="modal" aria-label="Close">Add Note</button>
	   <!--<button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
		<!--<div id="add_val" class="btn cp_cl close">Add</div>-->
      </div>
    </div>
  </div>
</div> 
	

 
