		<!--------Modal_1 -------->

						
<div class="modal fade" id="crown_modal_1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header allmodalheading">
		<h5>Select Teeth</h5>
       <!-- <button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
      </div>
      <div class="modal-body">
        <!---<div class="row">
          <div class="col-md-12">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<input type='checkbox' id="Uppers" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='Uppers'>
					<label for="Uppers">Uppers</label>
				</li>
			</ul>	
          </div>
        </div>--->
        <div class="row">
         <!-- <div class="col-md-1">
			<ul class="modal-ch">
				<li class="modal_li_full strighttext">
		          	<input type='checkbox' id="rhs" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='RHS'>
					<label for="rhs">R<br>H<br>S</label>
				</li>
			</ul>	
          </div>-->
          <div class="col-md-6 border_rightonepx">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="urq" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='URQ'>-->
			<label for="dental_exam_caries_urq">Upper Right</label>
				</li>
			</ul>
	        <div class="row">
	          <div class="col-md-12 border_bottomonepx">
				<ul class="modal-ch urq mb0" style="text-align: right;">
					<li class="">
			          	<input type='checkbox' id="Teeth_18" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='18'>
						<label for="Teeth_18">18</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Teeth_17" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='17'>
						<label for="Teeth_17">17</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Teeth_16" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='16'>
						<label for="Teeth_16">16</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Teeth_15" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='15'>
						<label for="Teeth_15">15</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Teeth_14" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='14'>
						<label for="Teeth_14">14</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Teeth_13" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='13'>
						<label for="Teeth_13">13</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Teeth_12" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='12'>
						<label for="Teeth_12">12</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Teeth_11" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='11'>
						<label for="Teeth_11">11</label>
					</li>
				</ul>
	          </div>
          	</div>
          	<div class="seprater"> </div>
	        <div class="row">
	          <div class="col-md-12">
				<ul class="modal-ch urq mb0" style="text-align: right;">
					<li class="">
						<input type='checkbox' id="Teeth_48" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='48'>
						<label for="Teeth_48">48</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Teeth_47" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='47'>
						<label for="Teeth_47">47</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Teeth_46" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='46'>
						<label for="Teeth_46">46</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Teeth_45" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='45'>
						<label for="Teeth_45">45</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Teeth_44" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='44'>
						<label for="Teeth_44">44</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Teeth_43" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='43'>
						<label for="Teeth_43">43</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Teeth_42" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='42'>
						<label for="Teeth_42">42</label>
					</li><li class="">
			          	<input type='checkbox' id="Teeth_41" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='41'>
						<label for="Teeth_41">41</label>
					</li>
				</ul>
	          </div>
          	</div>
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="dental_exam_caries_LRQ" name="dental_exam_caries" class="te_clcik" data-sectionId="teeth_sel" value='LRQ'>-->
					<label for="dental_exam_caries_LRQ">Lower Right</label>
				</li>
			</ul>
          </div>
          <div class="col-md-6">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="dental_exam_caries_ULQ" name="dental_exam_caries" class="te_clcik" data-sectionId="teeth_sel" value='ULQ'>-->
					<label for="dental_exam_caries_ULQ">Upper Left</label>
				</li>
			</ul>
	        <div class="row">
	          <div class="col-md-12 border_bottomonepx">
				<ul class="modal-ch urq mb0" style="text-align: left;">
					<li class="">
						<input type='checkbox' id="Teeth_21" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='21'>
						<label for="Teeth_21">21</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Teeth_22" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='22'>
						<label for="Teeth_22">22</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Teeth_23" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='23'>
						<label for="Teeth_23">23</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Teeth_24" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='24'>
						<label for="Teeth_24">24</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Teeth_25" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='25'>
						<label for="Teeth_25">25</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Teeth_26" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='26'>
						<label for="Teeth_26">26</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Teeth_27" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='27'>
						<label for="Teeth_27">27</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Teeth_28" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='28'>
						<label for="Teeth_28">28</label>
					</li>
				</ul>
	          </div>
          	</div>	
          	<div class="seprater"> </div>
	        <div class="row">
	          <div class="col-md-12">
				<ul class="modal-ch urq mb0" style="text-align: left;">
					<li class="">
						<input type='checkbox' id="Teeth_31" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='31'>
						<label for="Teeth_31">31</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Teeth_32" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='32'>
						<label for="Teeth_32">32</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Teeth_33" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='33'>
						<label for="Teeth_33">33</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Teeth_34" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='34'>
						<label for="Teeth_34">34</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Teeth_35" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='35'>
						<label for="Teeth_35">35</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Teeth_36" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='36'>
						<label for="Teeth_36">36</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Teeth_37" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='37'>
						<label for="Teeth_37">37</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Teeth_38" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='38'>
						<label for="Teeth_38">38</label>
					</li>
				</ul>
	          </div>
          	</div>	
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="dental_exam_caries_LLQ" name="dental_exam_caries" class="te_clcik" data-sectionId="teeth_sel" value='LLQ'>-->
					<label for="dental_exam_caries_LLQ">Lower Left</label>
				</li>
			</ul>
          </div>
          <!--<div class="col-md-1">
			<ul class="modal-ch">
				<li class="modal_li_full strighttext">
		          	<input type='checkbox' id="dental_exam_caries_lhs" name="dental_exam_caries" class="te_clcik" data-sectionId="teeth_sel" value='LHS'>
					<label for="dental_exam_caries_lhs">L<br>H<br>S</label>
				</li>
			</ul>	
          </div>-->
        </div>
       <!-- <div class="row">
          <div class="col-md-12">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<input type='checkbox' id="dental_exam_caries_Lowers" name="dental_exam_caries" class="te_clcik" data-sectionId="teeth_sel" value='Lowers'>
					<label for="dental_exam_caries_Lowers">Lowers</label>
				</li>
			</ul>	
          </div>
        </div>-->
      </div>
      <div class="modal-footer">
	  <button type="button" class="btn cp_cl closebtn each_model_data" id="" data-teethname="Teeth" data-spancls="crown_prep_teeth" data-checkedvalid="crown_teeth" data-clicked_1="co_option_sel" data-fieldname="dental_exam_caries" data-dismiss="modal" aria-label="Close">Add Note</button>
	
       <!--<button type="button" class="btn cp_cl closebtn" id="add_val_2" data-clicked="add_teeth" data-dismiss="modal" aria-label="Close">Add Note</button>-->
	   <!--<button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
		<!--<div id="add_val" class="btn cp_cl close">Add</div>-->
      </div>
    </div>
  </div>
</div>

<!-----------POPUP-ONE--------->

	<div class="modal fade" id="crown_modal_2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header allmodalheading">
		<h5>Select Shade</h5>
       <!-- <button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
      </div>
      <div class="modal-body">
        <div class="row">
       
         <div class="col-md-12">
	        <div class="row">
	         
				<ul class="modal-ch urq" style="text-align: center;">
				<p>Select one or more notes to insert.</p>
					<li class="">
			          	<input type='checkbox' id="shade_1" class="shade_select" data-sectionId="teeth_sel" name="shade_select" value='A1'>
						<label for="shade_1">A1</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="shade_2" class="shade_select" data-sectionId="teeth_sel" name="shade_select" value='A2'>
						<label for="shade_2">A2</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="shade_3" class="shade_select" data-sectionId="teeth_sel" name="shade_select" value='A3'>
						<label for="shade_3">A3</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="shade_4" class="shade_select" data-sectionId="teeth_sel" name="shade_select" value='A3.5'>
						<label for="shade_4">A3.5</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="shade_5" class="shade_select" data-sectionId="teeth_sel" name="shade_select" value='A4'>
						<label for="shade_5">A4</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="shade_6" class="shade_select" data-sectionId="teeth_sel" name="shade_select" value='B1'>
						<label for="shade_6">B1</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="shade_7" class="shade_select" data-sectionId="teeth_sel" name="shade_select" value='B2'>
						<label for="shade_7">B2</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="shade_8" class="shade_select" data-sectionId="teeth_sel" name="shade_select" value='B3'>
						<label for="shade_8">B3</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="shade_9" class="shade_select" data-sectionId="teeth_sel" name="shade_select" value='B4'>
						<label for="shade_9">B4</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="shade_10" class="shade_select" data-sectionId="teeth_sel" name="shade_select" value='C1'>
						<label for="shade_10">C1</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="shade_11" class="shade_select" data-sectionId="teeth_sel" name="shade_select" value='C2'>
						<label for="shade_11">C2</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="shade_12" class="shade_select" data-sectionId="teeth_sel" name="shade_select" value='C3'>
						<label for="shade_12">C3</label>
					</li>
										<li class="">
			          	<input type='checkbox' id="shade_13" class="shade_select" data-sectionId="teeth_sel" name="shade_select" value='C4'>
						<label for="shade_13">C4</label>
					</li>
										<li class="">
			          	<input type='checkbox' id="shade_14" class="shade_select" data-sectionId="teeth_sel" name="shade_select" value='D1'>
						<label for="shade_14">D1</label>
					</li>
										<li class="">
			          	<input type='checkbox' id="shade_15" class="shade_select" data-sectionId="teeth_sel" name="shade_select" value='D2'>
						<label for="shade_15">D2</label>
					</li>
										<li class="">
			          	<input type='checkbox' id="shade_16" class="shade_select" data-sectionId="teeth_sel" name="shade_select" value='D3'>
						<label for="shade_16">D3</label>
					</li>
										<li class="">
			          	<input type='checkbox' id="shade_17" class="shade_select" data-sectionId="teeth_sel" name="shade_select" value='D4'>
						<label for="shade_17">D4</label>
					</li>
										<li class="">
			          	<input type='checkbox' id="shade_18" class="shade_select" data-sectionId="teeth_sel" name="shade_select" value='Other'>
						<label for="shade_18">Other</label>
					</li>
				</ul>
         	</div>	
          </div>
        </div>

      </div>
      <div class="modal-footer">
       <button type="button" class="btn cp_cl closebtn each_model_data" id="add_val_demo" data-teethname="Shade" data-spancls="select_shade" data-checkedvalid="crown_teeth_shade" data-clicked_1="co_option_sel" data-fieldname="shade_select" data-dismiss="modal" aria-label="Close">Add Note</button>
	   <!--<button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
		<!--<div id="add_val" class="btn cp_cl close">Add</div>-->
      </div>
    </div>
  </div>
</div> 



 
