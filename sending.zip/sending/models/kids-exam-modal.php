<!--------Modal_1 -------->

<div class="modal fade" id="kids_exam_modal_1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header allmodalheading">
		<h5>Teeth charted : Select Teeth</h5>
       <!-- <button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
      </div>
      <div class="modal-body">
        <!--<div class="row">
          <div class="col-md-12">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<input type='checkbox' id="Uppers" class="irm_tth_fn" data-sectionId="teeth_sel" name="dental_exam_caries" value='Uppers'>
					<label for="Uppers">Uppers</label>
				</li>
			</ul>	
          </div>
        </div>-->
        <div class="row">
          <!--<div class="col-md-1">
			<ul class="modal-ch">
				<li class="modal_li_full strighttext">
		          	<input type='checkbox' id="rhs" class="irm_tth_fn" data-sectionId="teeth_sel" name="dental_exam_caries" value='RHS'>
					<label for="rhs">R<br>H<br>S</label>
				</li>
			</ul>	
          </div>-->
          <div class="col-md-6 border_rightonepx">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="urq" class="irm_tth_fn" data-sectionId="teeth_sel" name="dental_exam_caries" value='URQ'>-->
					<label for="urq">Upper Right</label>
				</li>
			</ul>
	        <div class="row">
	          <div class="col-md-12 border_bottomonepx">
				<ul class="modal-ch urq mb0" style="text-align: right;">
					<li class="">
			          	<input type='checkbox' id="kids_exam_18" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam_tth" value='18'>
						<label for="kids_exam_18">18</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_17" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam_tth" value='17'>
						<label for="kids_exam_17">17</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_16" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='16'>
						<label for="kids_exam_16">16</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_15" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='15'>
						<label for="kids_exam_15">15</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_14" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='14'>
						<label for="kids_exam_14">14</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_13" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='13'>
						<label for="kids_exam_13">13</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_12" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='12'>
						<label for="kids_exam_12">12</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_11" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='11'>
						<label for="kids_exam_11">11</label>
					</li>
				</ul>
	          </div>
          	</div>
          	<div class="seprater"> </div>
	        <div class="row">
	          <div class="col-md-12">
				<ul class="modal-ch urq mb0" style="text-align: right;">
					<li class="">
						<input type='checkbox' id="kids_exam_48" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='48'>
						<label for="kids_exam_48">48</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_47" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='47'>
						<label for="kids_exam_47">47</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_46" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='46'>
						<label for="kids_exam_46">46</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_45" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='45'>
						<label for="kids_exam_45">45</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_44" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='44'>
						<label for="kids_exam_44">44</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_43" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='43'>
						<label for="kids_exam_43">43</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_42" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='42'>
						<label for="kids_exam_42">42</label>
					</li><li class="">
			          	<input type='checkbox' id="kids_exam_41" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='41'>
						<label for="kids_exam_41">41</label>
					</li>

				</ul>
	          </div>
          	</div>	
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="LRQ" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='LRQ'>-->
					<label for="ULQ">Lower Right</label>
				</li>
			</ul>
          </div>
          <div class="col-md-6">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="ULQ" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='ULQ'>-->
					<label for="ULQ">Upper Left</label>
				</li>
			</ul>
	        <div class="row">
	          <div class="col-md-12 border_bottomonepx">
				<ul class="modal-ch urq mb0" style="text-align: left;">
					<li class="">
						<input type='checkbox' id="kids_exam_21" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='21'>
						<label for="kids_exam_21">21</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_22" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='22'>
						<label for="kids_exam_22">22</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_23" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='23'>
						<label for="kids_exam_23">23</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_24" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='24'>
						<label for="kids_exam_24">24</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_25" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='25'>
						<label for="kids_exam_25">25</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_26" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='26'>
						<label for="kids_exam_26">26</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_27" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='27'>
						<label for="kids_exam_27">27</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_28" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='28'>
						<label for="kids_exam_28">28</label>
					</li>
				</ul>
	          </div>
          	</div>	
          	<div class="seprater"> </div>
	        <div class="row">
	          <div class="col-md-12">
				<ul class="modal-ch urq mb0" style="text-align: left;">
					<li class="">
						<input type='checkbox' id="kids_exam_31" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='31'>
						<label for="kids_exam_31">31</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_32" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='32'>
						<label for="kids_exam_32">32</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_33" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='33'>
						<label for="kids_exam_33">33</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_34" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='34'>
						<label for="kids_exam_34">34</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_35" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='35'>
						<label for="kids_exam_35">35</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_36" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='36'>
						<label for="kids_exam_36">36</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_37" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='37'>
						<label for="kids_exam_37">37</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_38" class="kids_exam_fn" data-sectionId="teeth_sel" name="kids_exam" value='38'>
						<label for="kids_exam_38">38</label>
					</li>
				</ul>
	          </div>
          	</div>	
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="LLQ" class="irm_tth_fn" data-sectionId="teeth_sel" name="dental_exam_caries" value='LLQ'>-->
					<label for="LLQ">Lower Left</label>
				</li>
			</ul>
          </div>
         <!-- <div class="col-md-1">
			<ul class="modal-ch">
				<li class="modal_li_full strighttext">
		          	<input type='checkbox' id="lhs" class="irm_tth_fn" data-sectionId="teeth_sel" value='LHS'>
					<label for="lhs">L<br>H<br>S</label>
				</li>
			</ul>	
          </div>-->
        </div>
        <!--<div class="row">
          <div class="col-md-12">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<input type='checkbox' id="Lowers" class="irm_tth_fn" data-sectionId="teeth_sel" name="dental_exam_caries" value='Lowers'>
					<label for="Lowers">Lowers</label>
				</li>
			</ul>	
          </div>
        </div>-->
      </div>
      <div class="modal-footer">
	 
	 <button type="button" class="btn cp_cl closebtn each_model_data" id="" data-extractname="kids-exam-teeth" data-teethname="Teeth charted" data-spancls="kids-exam-charted" data-checkedvalid="kids-exam" data-clicked_1="co_option_sel" data-fieldname="kids_exam" data-dismiss="modal" aria-label="Close">Add Note</button>
     
	 </div>
    </div>
  </div>
</div>



<!--------Modal-2 -------->

<div class="modal fade" id="kids_exam_caries_modal_2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header allmodalheading">
		<h5>Caries : Select Teeth</h5>
       <!-- <button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
      </div>
      <div class="modal-body">
        <!--<div class="row">
          <div class="col-md-12">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<input type='checkbox' id="Uppers" class="irm_tth_fn" data-sectionId="teeth_sel" name="dental_exam_caries" value='Uppers'>
					<label for="Uppers">Uppers</label>
				</li>
			</ul>	
          </div>
        </div>-->
        <div class="row">
          <!--<div class="col-md-1">
			<ul class="modal-ch">
				<li class="modal_li_full strighttext">
		          	<input type='checkbox' id="rhs" class="irm_tth_fn" data-sectionId="teeth_sel" name="dental_exam_caries" value='RHS'>
					<label for="rhs">R<br>H<br>S</label>
				</li>
			</ul>	
          </div>-->
          <div class="col-md-6 border_rightonepx">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="urq" class="irm_tth_fn" data-sectionId="teeth_sel" name="dental_exam_caries" value='URQ'>-->
					<label for="urq">Upper Right</label>
				</li>
			</ul>
	        <div class="row">
	          <div class="col-md-12 border_bottomonepx">
				<ul class="modal-ch urq mb0" style="text-align: right;">
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_18" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='18'>
						<label for="kids_exam_caries_18">18</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_17" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='17'>
						<label for="kids_exam_caries_17">17</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_16" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='16'>
						<label for="kids_exam_caries_16">16</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_15" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='15'>
						<label for="kids_exam_caries_15">15</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_14" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='14'>
						<label for="kids_exam_caries_14">14</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_13" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='13'>
						<label for="kids_exam_caries_13">13</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_12" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='12'>
						<label for="kids_exam_caries_12">12</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_11" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='11'>
						<label for="kids_exam_caries_11">11</label>
					</li>
				</ul>
	          </div>
          	</div>
          	<div class="seprater"> </div>
	        <div class="row">
	          <div class="col-md-12">
				<ul class="modal-ch urq mb0" style="text-align: right;">
					<li class="">
						<input type='checkbox' id="kids_exam_caries_48" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='48'>
						<label for="kids_exam_caries_48">48</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_47" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='47'>
						<label for="kids_exam_caries_47">47</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_46" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='46'>
						<label for="kids_exam_caries_46">46</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_45" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='45'>
						<label for="kids_exam_caries_45">45</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_44" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='44'>
						<label for="kids_exam_caries_44">44</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_43" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='43'>
						<label for="kids_exam_caries_43">43</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_42" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='42'>
						<label for="kids_exam_caries_42">42</label>
					</li><li class="">
			          	<input type='checkbox' id="kids_exam_caries_41" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='41'>
						<label for="kids_exam_caries_41">41</label>
					</li>

				</ul>
	          </div>
          	</div>	
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="LRQ" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='LRQ'>-->
					<label for="ULQ">Lower Right</label>
				</li>
			</ul>
          </div>
          <div class="col-md-6">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="ULQ" class="irm_tth_fn" data-sectionId="teeth_sel" name="irm_tth" value='ULQ'>-->
					<label for="ULQ">Upper Left</label>
				</li>
			</ul>
	        <div class="row">
	          <div class="col-md-12 border_bottomonepx">
				<ul class="modal-ch urq mb0" style="text-align: left;">
					<li class="">
						<input type='checkbox' id="kids_exam_caries_21" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='21'>
						<label for="kids_exam_caries_21">21</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_22" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='22'>
						<label for="kids_exam_caries_22">22</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_23" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='23'>
						<label for="kids_exam_caries_23">23</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_24" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='24'>
						<label for="kids_exam_caries_24">24</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_25" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='25'>
						<label for="kids_exam_caries_25">25</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_26" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='26'>
						<label for="kids_exam_caries_26">26</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_27" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='27'>
						<label for="kids_exam_caries_27">27</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_28" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='28'>
						<label for="kids_exam_caries_28">28</label>
					</li>
				</ul>
	          </div>
          	</div>	
          	<div class="seprater"> </div>
	        <div class="row">
	          <div class="col-md-12">
				<ul class="modal-ch urq mb0" style="text-align: left;">
					<li class="">
						<input type='checkbox' id="kids_exam_caries_31" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='31'>
						<label for="kids_exam_caries_31">31</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_32" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='32'>
						<label for="kids_exam_caries_32">32</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_33" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='33'>
						<label for="kids_exam_caries_33">33</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_34" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='34'>
						<label for="kids_exam_caries_34">34</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_35" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='35'>
						<label for="kids_exam_caries_35">35</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_36" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='36'>
						<label for="kids_exam_caries_36">36</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_37" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='37'>
						<label for="kids_exam_caries_37">37</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="kids_exam_caries_38" class="kids_exam_caries_fn" data-sectionId="teeth_sel" name="kids_exam_caries" value='38'>
						<label for="kids_exam_caries_38">38</label>
					</li>
				</ul>
	          </div>
          	</div>	
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="LLQ" class="irm_tth_fn" data-sectionId="teeth_sel" name="dental_exam_caries" value='LLQ'>-->
					<label for="LLQ">Lower Left</label>
				</li>
			</ul>
          </div>
         <!-- <div class="col-md-1">
			<ul class="modal-ch">
				<li class="modal_li_full strighttext">
		          	<input type='checkbox' id="lhs" class="irm_tth_fn" data-sectionId="teeth_sel" value='LHS'>
					<label for="lhs">L<br>H<br>S</label>
				</li>
			</ul>	
          </div>-->
        </div>
        <!--<div class="row">
          <div class="col-md-12">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<input type='checkbox' id="Lowers" class="irm_tth_fn" data-sectionId="teeth_sel" name="dental_exam_caries" value='Lowers'>
					<label for="Lowers">Lowers</label>
				</li>
			</ul>	
          </div>
        </div>-->
      </div>
      <div class="modal-footer">
	 
	 <button type="button" class="btn cp_cl closebtn each_model_data" id="" data-extractname="kids-exam-caries" data-teethname="Caries" data-spancls="kids-exam-caries" data-checkedvalid="kids-exam-caries-frm" data-clicked_1="co_option_sel" data-fieldname="kids_exam_caries" data-dismiss="modal" aria-label="Close">Add Note</button>
     
	 </div>
    </div>
  </div>
</div>

