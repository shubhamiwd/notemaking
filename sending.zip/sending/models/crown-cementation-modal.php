		<!--------Modal_1 -------->


		<div class="modal fade" id="crown_modal_22" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		    <div class="modal-dialog modal-lg" role="document">
		        <div class="modal-content">
		            <div class="modal-header allmodalheading">
		<h5>Select Teeth</h5>
       <!-- <button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
      </div>
		            <div class="modal-body">
		                <div class="row">
		                    <div class="col-md-6 border_rightonepx">
		                        <ul class="modal-ch">
		                            <li class="modal_li_full">

		                                <label for="dental_exam_caries_urq">Upper Right</label>
		                            </li>
		                        </ul>
		                        <div class="row">
		                            <div class="col-md-12 border_bottomonepx">
		                                <ul class="modal-ch urq mb0" style="text-align: right;">
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_18" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='18'>
		                                        <label for="Teeth_18">18</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_17" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='17'>
		                                        <label for="Teeth_17">17</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_16" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='16'>
		                                        <label for="Teeth_16">16</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_15" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='15'>
		                                        <label for="Teeth_15">15</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_14" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='14'>
		                                        <label for="Teeth_14">14</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_13" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='13'>
		                                        <label for="Teeth_13">13</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_12" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='12'>
		                                        <label for="Teeth_12">12</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_11" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='11'>
		                                        <label for="Teeth_11">11</label>
		                                    </li>
		                                </ul>
		                            </div>
		                        </div>
		                        <div class="seprater"> </div>
		                        <div class="row">
		                            <div class="col-md-12">
		                                <ul class="modal-ch urq mb0" style="text-align: right;">
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_48" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='48'>
		                                        <label for="Teeth_48">48</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_47" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='47'>
		                                        <label for="Teeth_47">47</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_46" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='46'>
		                                        <label for="Teeth_46">46</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_45" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='45'>
		                                        <label for="Teeth_45">45</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_44" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='44'>
		                                        <label for="Teeth_44">44</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_43" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='43'>
		                                        <label for="Teeth_43">43</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_42" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='42'>
		                                        <label for="Teeth_42">42</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_41" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='41'>
		                                        <label for="Teeth_41">41</label>
		                                    </li>
		                                </ul>
		                            </div>
		                        </div>
		                        <ul class="modal-ch">
		                            <li class="modal_li_full">
		                                <!--<input type='checkbox' id="dental_exam_caries_LRQ" name="dental_exam_caries" class="te_clcik" data-sectionId="teeth_sel" value='LRQ'>-->
		                                <label for="dental_exam_caries_LRQ">Lower Right</label>
		                            </li>
		                        </ul>
		                    </div>
		                    <div class="col-md-6">
		                        <ul class="modal-ch">
		                            <li class="modal_li_full">

		                                <label for="dental_exam_caries_ULQ">Upper Left</label>
		                            </li>
		                        </ul>
		                        <div class="row">
		                            <div class="col-md-12 border_bottomonepx">
		                                <ul class="modal-ch urq mb0" style="text-align: left;">
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_21" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='21'>
		                                        <label for="Teeth_21">21</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_22" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='22'>
		                                        <label for="Teeth_22">22</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_23" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='23'>
		                                        <label for="Teeth_23">23</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_24" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='24'>
		                                        <label for="Teeth_24">24</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_25" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='25'>
		                                        <label for="Teeth_25">25</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_26" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='26'>
		                                        <label for="Teeth_26">26</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_27" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='27'>
		                                        <label for="Teeth_27">27</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_28" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='28'>
		                                        <label for="Teeth_28">28</label>
		                                    </li>
		                                </ul>
		                            </div>
		                        </div>
		                        <div class="seprater"> </div>
		                        <div class="row">
		                            <div class="col-md-12">
		                                <ul class="modal-ch urq mb0" style="text-align: left;">
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_31" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='31'>
		                                        <label for="Teeth_31">31</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_32" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='32'>
		                                        <label for="Teeth_32">32</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_33" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='33'>
		                                        <label for="Teeth_33">33</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_34" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='34'>
		                                        <label for="Teeth_34">34</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_35" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='35'>
		                                        <label for="Teeth_35">35</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_36" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='36'>
		                                        <label for="Teeth_36">36</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_37" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='37'>
		                                        <label for="Teeth_37">37</label>
		                                    </li>
		                                    <li class="">
		                                        <input type='checkbox' id="Teeth_38" class="te_clcik"
		                                            data-sectionId="teeth_sel" name="dental_exam_caries" value='38'>
		                                        <label for="Teeth_38">38</label>
		                                    </li>
		                                </ul>
		                            </div>
		                        </div>
		                        <ul class="modal-ch">
		                            <li class="modal_li_full">

		                                <label for="dental_exam_caries_LLQ">Lower Left</label>
		                            </li>
		                        </ul>
		                    </div>

		                </div>

		            </div>
		            <div class="modal-footer">
		                <button type="button" class="btn cp_cl closebtn each_model_data" id="" data-teethname="Caries"
		                    data-spancls="sel_teeth_2" data-checkedvalid="select_teeth_2" data-clicked_1="co_option_sel"
		                    data-fieldname="dental_exam_caries" data-dismiss="modal" aria-label="Close">Add Note</button>


		            </div>
		        </div>
		    </div>
		</div>
	