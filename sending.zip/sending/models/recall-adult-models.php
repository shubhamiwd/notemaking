	
	<!-----------POPUP-ONE--------->
	<div class="modal fade" id="myModal_1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-lg small_popup" role="document">
    <div class="modal-content">
      <div class="modal-header allmodalheading">
		<h5>C/O</h5>
       <!-- <button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
      </div>
      <div class="modal-body">
        <div class="row">
       
         <div class="col-md-12">
	        <div class="row">
	         
				<ul class="modal-ch urq" style="text-align: center;">
					<li class="">
			          	<input type='checkbox' id="co_1" class="co_select" data-sectionId="teeth_sel" name="co_select" value='Nil'>
						<label for="co_1">Nil</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="co_2" class="co_select" data-sectionId="teeth_sel" name="co_select" value='Pain'>
						<label for="co_2">Pain</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="co_3" class="co_select" data-sectionId="teeth_sel" name="co_select" value='Sensitivity'>
						<label for="co_3">Sensitivity</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="co_4" class="co_select" data-sectionId="teeth_sel" name="co_select" value='Other'>
						<label for="co_4">Other</label>
					</li>
				</ul>
         	</div>	
          </div>
        </div>

      </div>
      <div class="modal-footer">
       <button type="button" class="btn cp_cl closebtn each_model_data" data-teethname="C/O" id="add_val_demo" data-spancls="co_sel_teeth" data-checkedvalid="co_sel" data-clicked_1="co_option_sel" data-fieldname="co_select" data-dismiss="modal" aria-label="Close">Add Note</button>
	   <!--<button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
		<!--<div id="add_val" class="btn cp_cl close">Add</div>-->
      </div>
    </div>
  </div>
</div> 
		<!--------Modal_2 -------->

						
<div class="modal fade" id="myModal_2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header allmodalheading">
		<h5>Caries : Select Teeth</h5>
       <!-- <button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
      </div>
      <div class="modal-body">
        <!--<div class="row">
          <div class="col-md-12">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<input type='checkbox' id="Uppers" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='Uppers'>
					<label for="Uppers">Uppers</label>
				</li>
			</ul>	
          </div>
        </div>-->
        <div class="row">
          <!--<div class="col-md-1">
			<ul class="modal-ch">
				<li class="modal_li_full strighttext">
		          	<input type='checkbox' id="rhs" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='RHS'>
					<label for="rhs">R<br>H<br>S</label>
				</li>
			</ul>	
          </div>-->
          <div class="col-md-6 border_rightonepx">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="urq" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='URQ'>-->
					<label for="urq">Upper Right</label>
				</li>
			</ul>
	        <div class="row">
	          <div class="col-md-12 border_bottomonepx">
				<ul class="modal-ch urq mb0" style="text-align: right;">
					<li class="">
			          	<input type='checkbox' id="Caries_18" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='18'>
						<label for="Caries_18">18</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Caries_17" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='17'>
						<label for="Caries_17">17</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Caries_16" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='16'>
						<label for="Caries_16">16</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Caries_15" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='15'>
						<label for="Caries_15">15</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Caries_14" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='14'>
						<label for="Caries_14">14</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Caries_13" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='13'>
						<label for="Caries_13">13</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Caries_12" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='12'>
						<label for="Caries_12">12</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Caries_11" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='11'>
						<label for="Caries_11">11</label>
					</li>
				</ul>
	          </div>
          	</div>
          	<div class="seprater"> </div>
	        <div class="row">
	          <div class="col-md-12">
				<ul class="modal-ch urq mb0" style="text-align: right;">
					<li class="">
						<input type='checkbox' id="Caries_48" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='48'>
						<label for="Caries_48">48</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Caries_47" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='47'>
						<label for="Caries_47">47</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Caries_46" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='46'>
						<label for="Caries_46">46</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Caries_45" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='45'>
						<label for="Caries_45">45</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Caries_44" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='44'>
						<label for="Caries_44">44</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Caries_43" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='43'>
						<label for="Caries_43">43</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Caries_42" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='42'>
						<label for="Caries_42">42</label>
					</li><li class="">
			          	<input type='checkbox' id="Caries_41" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='41'>
						<label for="Caries_41">41</label>
					</li>

				</ul>
	          </div>
          	</div>	
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="LRQ" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='LRQ'>-->
					<label for="ULQ">Lower Right</label>
				</li>
			</ul>
          </div>
          <div class="col-md-6">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="ULQ" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='ULQ'>-->
					<label for="ULQ">Upper Left</label>
				</li>
			</ul>
	        <div class="row">
	          <div class="col-md-12 border_bottomonepx">
				<ul class="modal-ch urq mb0" style="text-align: left;">
					<li class="">
						<input type='checkbox' id="Caries_21" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='21'>
						<label for="Caries_21">21</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Caries_22" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='22'>
						<label for="Caries_22">22</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Caries_23" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='23'>
						<label for="Caries_23">23</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Caries_24" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='24'>
						<label for="Caries_24">24</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Caries_25" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='25'>
						<label for="Caries_25">25</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Caries_26" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='26'>
						<label for="Caries_26">26</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Caries_27" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='27'>
						<label for="Caries_27">27</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Caries_28" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='28'>
						<label for="Caries_28">28</label>
					</li>
				</ul>
	          </div>
          	</div>	
          	<div class="seprater"> </div>
	        <div class="row">
	          <div class="col-md-12">
				<ul class="modal-ch urq mb0" style="text-align: left;">
					<li class="">
						<input type='checkbox' id="Caries_31" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='31'>
						<label for="Caries_31">31</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Caries_32" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='32'>
						<label for="Caries_32">32</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Caries_33" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='33'>
						<label for="Caries_33">33</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Caries_34" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='34'>
						<label for="Caries_34">34</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Caries_35" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='35'>
						<label for="Caries_35">35</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Caries_36" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='36'>
						<label for="Caries_36">36</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Caries_37" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='37'>
						<label for="Caries_37">37</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Caries_38" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='38'>
						<label for="Caries_38">38</label>
					</li>
				</ul>
	          </div>
          	</div>	
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="LLQ" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='LLQ'>-->
					<label for="LLQ">Lower Left</label>
				</li>
			</ul>
          </div>
         <!-- <div class="col-md-1">
			<ul class="modal-ch">
				<li class="modal_li_full strighttext">
		          	<input type='checkbox' id="lhs" class="te_clcik" data-sectionId="teeth_sel" value='LHS'>
					<label for="lhs">L<br>H<br>S</label>
				</li>
			</ul>	
          </div>-->
        </div>
        <!--<div class="row">
          <div class="col-md-12">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<input type='checkbox' id="Lowers" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='Lowers'>
					<label for="Lowers">Lowers</label>
				</li>
			</ul>	
          </div>
        </div>-->
      </div>
      <div class="modal-footer">
	 
	 <button type="button" class="btn cp_cl closebtn each_model_data" id="" data-teethname="Caries" data-spancls="sel_teeth_2" data-checkedvalid="select_teeth_2" data-clicked_1="co_option_sel" data-fieldname="dental_exam_caries" data-dismiss="modal" aria-label="Close">Add Note</button>
     
	 </div>
    </div>
  </div>
</div>

<!-------------Model_3----------------->

<div class="modal fade" id="myModal_3" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header allmodalheading">
		<h5>Leaking or defective restorations : Select Teeth</h5>
       <!-- <button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
      </div>
      <div class="modal-body">
        <!--<div class="row">
          <div class="col-md-12">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<input type='checkbox' id="dental_exam_resto_Uppers" name="dental_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='Uppers'>
					<label for="dental_exam_resto_Uppers">Uppers</label>
				</li>
			</ul>	
          </div>
        </div>-->
        <div class="row">
          <!--<div class="col-md-1">
			<ul class="modal-ch">
				<li class="modal_li_full strighttext">
		          	<input type='checkbox' id="dental_exam_resto_rhs" name="dental_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='RHS'>
					<label for="dental_exam_resto_rhs">R<br>H<br>S</label>
				</li>
			</ul>	
          </div>-->
          <div class="col-md-6 border_rightonepx">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="dental_exam_resto_urq" name="dental_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='URQ'>-->
					<label for="dental_exam_resto_urq">Upper Right</label>
				</li>
			</ul>
	        <div class="row">
	          <div class="col-md-12 border_bottomonepx">
				<ul class="modal-ch urq mb0" style="text-align: right;">
					<li class="">
			          	<input type='checkbox' id="Leaking_18" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='18'>
						<label for="Leaking_18">18</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Leaking_17" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='17'>
						<label for="Leaking_17">17</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Leaking_16" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='16'>
						<label for="Leaking_16">16</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Leaking_15" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='15'>
						<label for="Leaking_15">15</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Leaking_14" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='14'>
						<label for="Leaking_14">14</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Leaking_13" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='13'>
						<label for="Leaking_13">13</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Leaking_12" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='12'>
						<label for="Leaking_12">12</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Leaking_11" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='11'>
						<label for="Leaking_11">11</label>
					</li>
				</ul>
	          </div>
          	</div>
          	<div class="seprater"> </div>
	        <div class="row">
	          <div class="col-md-12">
				<ul class="modal-ch urq mb0" style="text-align: right;">
					<li class="">
						<input type='checkbox' id="Leaking_48" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='48'>
						<label for="Leaking_48">48</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Leaking_47" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='47'>
						<label for="Leaking_47">47</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Leaking_46" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='46'>
						<label for="Leaking_46">46</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Leaking_45" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='45'>
						<label for="Leaking_45">45</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Leaking_44" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='44'>
						<label for="Leaking_44">44</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Leaking_43" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='43'>
						<label for="Leaking_43">43</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Leaking_42" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='42'>
						<label for="Leaking_42">42</label>
					</li><li class="">
			          	<input type='checkbox' id="Leaking_41" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='41'>
						<label for="Leaking_41">41</label>
					</li>
				</ul>
	          </div>
          	</div>	
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="dental_exam_resto_LRQ" name="dental_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='LRQ'>-->
					<label for="dental_exam_resto_LRQ">Lower Right</label>
				</li>
			</ul>
          </div>
          <div class="col-md-6">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="dental_exam_resto_ULQ" name="dental_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='ULQ'>-->
					<label for="dental_exam_resto_ULQ">Upper Left</label>
				</li>
			</ul>
	        <div class="row">
	          <div class="col-md-12 border_bottomonepx">
				<ul class="modal-ch urq mb0" style="text-align: left;">
					<li class="">
						<input type='checkbox' id="Leaking_21" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='21'>
						<label for="Leaking_21">21</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Leaking_22" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='22'>
						<label for="Leaking_22">22</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Leaking_23" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='23'>
						<label for="Leaking_23">23</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Leaking_24" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='24'>
						<label for="Leaking_24">24</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Leaking_25" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='25'>
						<label for="Leaking_25">25</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Leaking_26" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='26'>
						<label for="Leaking_26">26</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Leaking_27" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='27'>
						<label for="Leaking_27">27</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Leaking_28" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='28'>
						<label for="Leaking_28">28</label>
					</li>
				</ul>
	          </div>
          	</div>	
          	<div class="seprater"> </div>
	        <div class="row">
	          <div class="col-md-12">
				<ul class="modal-ch urq mb0" style="text-align: left;">
					<li class="">
						<input type='checkbox' id="Leaking_31" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='31'>
						<label for="Leaking_31">31</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Leaking_32" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='32'>
						<label for="Leaking_32">32</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Leaking_33" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='33'>
						<label for="Leaking_33">33</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Leaking_34" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='34'>
						<label for="Leaking_34">34</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Leaking_35" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='35'>
						<label for="Leaking_35">35</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Leaking_36" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='36'>
						<label for="Leaking_36">36</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Leaking_37" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='37'>
						<label for="Leaking_37">37</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="Leaking_38" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_resto" value='38'>
						<label for="Leaking_38">38</label>
					</li>
				</ul>
	          </div>
          	</div>	
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="dental_exam_resto_LLQ" name="dental_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='LLQ'>-->
					<label for="dental_exam_resto_LLQ">Lower Left</label>
				</li>
			</ul>
          </div>
          <!--<div class="col-md-1">
			<ul class="modal-ch">
				<li class="modal_li_full strighttext">
		          	<input type='checkbox' id="dental_exam_resto_lhs" name="dental_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='LHS'>
					<label for="dental_exam_resto_lhs">L<br>H<br>S</label>
				</li>
			</ul>	
          </div>-->
        </div>
       <!-- <div class="row">
          <div class="col-md-12">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<input type='checkbox' id="dental_exam_resto_Lowers" name="dental_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='Lowers'>
					<label for="dental_exam_resto_Lowers">Lowers</label>
				</li>
			</ul>	
          </div>
        </div>-->
      </div>
      <div class="modal-footer">
	
	<button type="button" class="btn cp_cl closebtn each_model_data" id="add_val_demo" data-teethname="Leaking or defective restorations" data-spancls="sel_teeth_3" data-checkedvalid="select_teeth_3" data-fieldname="dental_exam_resto" data-dismiss="modal" aria-label="Close">Add Note</button>
	
      </div>
    </div>
  </div>
</div>

<!-------------Model_4----------------->

<div class="modal fade" id="myModal_4" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header allmodalheading">
		<h5>Mobility : Select Teeth</h5>
       <!-- <button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
      </div>
      <div class="modal-body">
        <!--<div class="row">
          <div class="col-md-12">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<input type='checkbox' id="mobility_Uppers" name="mobility_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='Uppers'>
					<label for="mobility_Uppers">Uppers</label>
				</li>
			</ul>	
          </div>
        </div>-->
        <div class="row">
         <!-- <div class="col-md-1">
			<ul class="modal-ch">
				<li class="modal_li_full strighttext">
		          	<input type='checkbox' id="mobility_rhs" name="mobility_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='RHS'>
					<label for="mobility_rhs">R<br>H<br>S</label>
				</li>
			</ul>	
          </div>-->
          <div class="col-md-6 border_rightonepx">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="mobility_urq" name="mobility_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='URQ'>-->
					<label for="mobility_urq">Upper Right</label>
				</li>
			</ul>
	        <div class="row">
	          <div class="col-md-12 border_bottomonepx">
				<ul class="modal-ch urq mb0" style="text-align: right;">
										<li class="">
			          	<input type='checkbox' id="mobility_18" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='18'>
						<label for="mobility_18">18</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mobility_17" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='17'>
						<label for="mobility_17">17</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mobility_16" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='16'>
						<label for="mobility_16">16</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mobility_15" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='15'>
						<label for="mobility_15">15</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mobility_14" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='14'>
						<label for="mobility_14">14</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mobility_13" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='13'>
						<label for="mobility_13">13</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mobility_12" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='12'>
						<label for="mobility_12">12</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mobility_11" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='11'>
						<label for="mobility_11">11</label>
					</li>
				</ul>
	          </div>
          	</div>
          	<div class="seprater"> </div>
	        <div class="row">
	          <div class="col-md-12">
				<ul class="modal-ch urq mb0" style="text-align: right;">
										<li class="">
						<input type='checkbox' id="mobility_48" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='48'>
						<label for="mobility_48">48</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mobility_47" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='47'>
						<label for="mobility_47">47</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mobility_46" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='46'>
						<label for="mobility_46">46</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mobility_45" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='45'>
						<label for="mobility_45">45</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mobility_44" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='44'>
						<label for="mobility_44">44</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mobility_43" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='43'>
						<label for="mobility_43">43</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mobility_42" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='42'>
						<label for="mobility_42">42</label>
					</li><li class="">
			          	<input type='checkbox' id="mobility_41" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='41'>
						<label for="mobility_41">41</label>
					</li>
				</ul>
	          </div>
          	</div>	
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="mobility_LRQ" name="mobility_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='LRQ'>-->
					<label for="mobility_LRQ">Lower Right</label>
				</li>
			</ul>
          </div>
          <div class="col-md-6">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="mobility_ULQ" name="mobility_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='ULQ'>-->
					<label for="mobility_ULQ">Upper Left</label>
				</li>
			</ul>
	        <div class="row">
	          <div class="col-md-12 border_bottomonepx">
				<ul class="modal-ch urq mb0" style="text-align: left;">
										<li class="">
						<input type='checkbox' id="mobility_21" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='21'>
						<label for="mobility_21">21</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mobility_22" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='22'>
						<label for="mobility_22">22</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mobility_23" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='23'>
						<label for="mobility_23">23</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mobility_24" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='24'>
						<label for="mobility_24">24</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mobility_25" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='25'>
						<label for="mobility_25">25</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mobility_26" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='26'>
						<label for="mobility_26">26</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mobility_27" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='27'>
						<label for="mobility_27">27</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mobility_28" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='28'>
						<label for="mobility_28">28</label>
					</li>
				</ul>
	          </div>
          	</div>	
          	<div class="seprater"> </div>
	        <div class="row">
	          <div class="col-md-12">
				<ul class="modal-ch urq mb0" style="text-align: left;">
					<li class="">
						<input type='checkbox' id="mobility_31" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='31'>
						<label for="mobility_31">31</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mobility_32" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='32'>
						<label for="mobility_32">32</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mobility_33" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='33'>
						<label for="mobility_33">33</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mobility_34" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='34'>
						<label for="mobility_34">34</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mobility_35" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='35'>
						<label for="mobility_35">35</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mobility_36" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='36'>
						<label for="mobility_36">36</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mobility_37" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='37'>
						<label for="mobility_37">37</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mobility_38" class="te_clcik" data-sectionId="teeth_sel" name="mobility_exam_resto" value='38'>
						<label for="mobility_38">38</label>
					</li>
				</ul>
	          </div>
          	</div>	
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="mobility_LLQ" name="mobility_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='LLQ'>-->
					<label for="mobility_LLQ">Lower Left</label>
				</li>
			</ul>
          </div>
          <!--<div class="col-md-1">
			<ul class="modal-ch">
				<li class="modal_li_full strighttext">
		          	<input type='checkbox' id="mobility_lhs" name="mobility_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='LHS'>
					<label for="mobility_lhs">L<br>H<br>S</label>
				</li>
			</ul>	
          </div>-->
        </div>
        <!--<div class="row">
          <div class="col-md-12">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<input type='checkbox' id="mobility_Lowers" name="mobility_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='Lowers'>
					<label for="mobility_Lowers">Lowers</label>
				</li>
			</ul>	
          </div>
        </div>-->
      </div>
      <div class="modal-footer">
	
		<button type="button" class="btn cp_cl closebtn each_model_data" id="add_val_demo" data-teethname="Mobility" data-spancls="sel_teeth_4" data-checkedvalid="select_teeth_4" data-fieldname="mobility_exam_resto" data-dismiss="modal" aria-label="Close">Add Note</button>
	
      </div>
    </div>
  </div>
</div>


 
