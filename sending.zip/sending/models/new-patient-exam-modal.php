	
	<!-----------POPUP-ONE--------->
	<div class="modal fade" id="myModal_1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-lg small_popup" role="document">
    <div class="modal-content">
      <div class="modal-header allmodalheading">
		<h5>C/O</h5>
       <!-- <button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
      </div>
      <div class="modal-body">
        <div class="row">
         <div class="col-md-12">
	        <div class="row">
				<ul class="modal-ch urq" style="text-align: center;">
					<li class="">
			          	<input type='checkbox' id="npe_op1" class="co_select" data-sectionId="teeth_sel" name="npe_op" value='Nil'>
						<label for="npe_op1">Nil</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="npe_op2" class="co_select" data-sectionId="teeth_sel" name="npe_op" value='Pain'>
						<label for="npe_op2">Pain</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="npe_op3" class="co_select" data-sectionId="teeth_sel" name="npe_op" value='Sensitivity'>
						<label for="npe_op3">Sensitivity</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="npe_op4" class="co_select" data-sectionId="teeth_sel" name="npe_op" value='Other'>
						<label for="npe_op4">Other</label>
					</li>
				</ul>
         	</div>	
          </div>
        </div>

      </div>
      <div class="modal-footer">
       <button type="button" class="btn cp_cl closebtn each_model_data" data-teethname="C/O" id="add_val_demo" data-spancls="npe_opt" data-checkedvalid="co_sel" data-clicked_1="co_option_sel" data-fieldname="npe_op" data-dismiss="modal" aria-label="Close">Add Note</button>
	   <!--<button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
		<!--<div id="add_val" class="btn cp_cl close">Add</div>-->
      </div>
    </div>
  </div>
</div> 


<!--------Modal_2 -------->

<div class="modal fade" id="myModal_2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header allmodalheading">
		<h5>Caries : Select Teeth</h5>
       <!-- <button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
      </div>
      <div class="modal-body">
        <!--<div class="row">
          <div class="col-md-12">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<input type='checkbox' id="Uppers" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='Uppers'>
					<label for="Uppers">Uppers</label>
				</li>
			</ul>	
          </div>
        </div>-->
        <div class="row">
          <!--<div class="col-md-1">
			<ul class="modal-ch">
				<li class="modal_li_full strighttext">
		          	<input type='checkbox' id="rhs" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='RHS'>
					<label for="rhs">R<br>H<br>S</label>
				</li>
			</ul>	
          </div>-->
          <div class="col-md-6 border_rightonepx">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="urq" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='URQ'>-->
					<label for="urq">Upper Right</label>
				</li>
			</ul>
	        <div class="row">
	          <div class="col-md-12 border_bottomonepx">
				<ul class="modal-ch urq mb0" style="text-align: right;">
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_18" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='18'>
						<label for="pat_e_tth_18">18</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_17" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='17'>
						<label for="pat_e_tth_17">17</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_16" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='16'>
						<label for="pat_e_tth_16">16</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_15" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='15'>
						<label for="pat_e_tth_15">15</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_14" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='14'>
						<label for="pat_e_tth_14">14</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_13" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='13'>
						<label for="pat_e_tth_13">13</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_12" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='12'>
						<label for="pat_e_tth_12">12</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_11" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='11'>
						<label for="pat_e_tth_11">11</label>
					</li>
				</ul>
	          </div>
          	</div>
          	<div class="seprater"> </div>
	        <div class="row">
	          <div class="col-md-12">
				<ul class="modal-ch urq mb0" style="text-align: right;">
					<li class="">
						<input type='checkbox' id="pat_e_tth_48" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='48'>
						<label for="pat_e_tth_48">48</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_47" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='47'>
						<label for="pat_e_tth_47">47</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_46" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='46'>
						<label for="pat_e_tth_46">46</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_45" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='45'>
						<label for="pat_e_tth_45">45</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_44" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='44'>
						<label for="pat_e_tth_44">44</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_43" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='43'>
						<label for="pat_e_tth_43">43</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_42" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='42'>
						<label for="pat_e_tth_42">42</label>
					</li><li class="">
			          	<input type='checkbox' id="pat_e_tth_41" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='41'>
						<label for="pat_e_tth_41">41</label>
					</li>

				</ul>
	          </div>
          	</div>	
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="LRQ" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='LRQ'>-->
					<label for="ULQ">Lower Right</label>
				</li>
			</ul>
          </div>
          <div class="col-md-6">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="ULQ" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='ULQ'>-->
					<label for="ULQ">Upper Left</label>
				</li>
			</ul>
	        <div class="row">
	          <div class="col-md-12 border_bottomonepx">
				<ul class="modal-ch urq mb0" style="text-align: left;">
					<li class="">
						<input type='checkbox' id="pat_e_tth_21" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='21'>
						<label for="pat_e_tth_21">21</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_22" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='22'>
						<label for="pat_e_tth_22">22</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_23" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='23'>
						<label for="pat_e_tth_23">23</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_24" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='24'>
						<label for="pat_e_tth_24">24</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_25" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='25'>
						<label for="pat_e_tth_25">25</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_26" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='26'>
						<label for="pat_e_tth_26">26</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_27" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='27'>
						<label for="pat_e_tth_27">27</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_28" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='28'>
						<label for="pat_e_tth_28">28</label>
					</li>
				</ul>
	          </div>
          	</div>	
          	<div class="seprater"> </div>
	        <div class="row">
	          <div class="col-md-12">
				<ul class="modal-ch urq mb0" style="text-align: left;">
					<li class="">
						<input type='checkbox' id="pat_e_tth_31" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='31'>
						<label for="pat_e_tth_31">31</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_32" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='32'>
						<label for="pat_e_tth_32">32</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_33" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='33'>
						<label for="pat_e_tth_33">33</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_34" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='34'>
						<label for="pat_e_tth_34">34</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_35" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='35'>
						<label for="pat_e_tth_35">35</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_36" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='36'>
						<label for="pat_e_tth_36">36</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_37" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='37'>
						<label for="pat_e_tth_37">37</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="pat_e_tth_38" class="te_clcik" data-sectionId="teeth_sel" name="pat_e_tth" value='38'>
						<label for="pat_e_tth_38">38</label>
					</li>
				</ul>
	          </div>
          	</div>	
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="LLQ" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='LLQ'>-->
					<label for="LLQ">Lower Left</label>
				</li>
			</ul>
          </div>
         <!-- <div class="col-md-1">
			<ul class="modal-ch">
				<li class="modal_li_full strighttext">
		          	<input type='checkbox' id="lhs" class="te_clcik" data-sectionId="teeth_sel" value='LHS'>
					<label for="lhs">L<br>H<br>S</label>
				</li>
			</ul>	
          </div>-->
        </div>
        <!--<div class="row">
          <div class="col-md-12">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<input type='checkbox' id="Lowers" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='Lowers'>
					<label for="Lowers">Lowers</label>
				</li>
			</ul>	
          </div>
        </div>-->
      </div>
      <div class="modal-footer">
	 
	 <button type="button" class="btn cp_cl closebtn each_model_data" id="" data-teethname="Caries" data-spancls="pat_exam_teeth_1" data-checkedvalid="pat_e_1" data-clicked_1="co_option_sel" data-fieldname="pat_e_tth" data-dismiss="modal" aria-label="Close">Add Note</button>
     
	 </div>
    </div>
  </div>
</div>

<!-------------Model_3----------------->

<div class="modal fade" id="myModal_3" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header allmodalheading">
		<h5>Leaking or defective restorations : Select Teeth</h5>
       <!-- <button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
      </div>
      <div class="modal-body">
        <!--<div class="row">
          <div class="col-md-12">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<input type='checkbox' id="dental_exam_resto_Uppers" name="dental_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='Uppers'>
					<label for="dental_exam_resto_Uppers">Uppers</label>
				</li>
			</ul>	
          </div>
        </div>-->
        <div class="row">
          <!--<div class="col-md-1">
			<ul class="modal-ch">
				<li class="modal_li_full strighttext">
		          	<input type='checkbox' id="dental_exam_resto_rhs" name="dental_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='RHS'>
					<label for="dental_exam_resto_rhs">R<br>H<br>S</label>
				</li>
			</ul>	
          </div>-->
          <div class="col-md-6 border_rightonepx">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="dental_exam_resto_urq" name="dental_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='URQ'>-->
					<label for="dental_exam_resto_urq">Upper Right</label>
				</li>
			</ul>
	        <div class="row">
	          <div class="col-md-12 border_bottomonepx">
				<ul class="modal-ch urq mb0" style="text-align: right;">
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_18" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='18'>
						<label for="leak_def_tth_18">18</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_17" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='17'>
						<label for="leak_def_tth_17">17</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_16" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='16'>
						<label for="leak_def_tth_16">16</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_15" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='15'>
						<label for="leak_def_tth_15">15</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_14" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='14'>
						<label for="leak_def_tth_14">14</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_13" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='13'>
						<label for="leak_def_tth_13">13</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_12" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='12'>
						<label for="leak_def_tth_12">12</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_11" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='11'>
						<label for="leak_def_tth_11">11</label>
					</li>
				</ul>
	          </div>
          	</div>
          	<div class="seprater"> </div>
	        <div class="row">
	          <div class="col-md-12">
				<ul class="modal-ch urq mb0" style="text-align: right;">
					<li class="">
						<input type='checkbox' id="leak_def_tth_48" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='48'>
						<label for="leak_def_tth_48">48</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_47" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='47'>
						<label for="leak_def_tth_47">47</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_46" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='46'>
						<label for="leak_def_tth_46">46</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_45" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='45'>
						<label for="leak_def_tth_45">45</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_44" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='44'>
						<label for="leak_def_tth_44">44</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_43" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='43'>
						<label for="leak_def_tth_43">43</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_42" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='42'>
						<label for="leak_def_tth_42">42</label>
					</li><li class="">
			          	<input type='checkbox' id="leak_def_tth_41" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='41'>
						<label for="leak_def_tth_41">41</label>
					</li>
				</ul>
	          </div>
          	</div>	
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="leak_def_r_LRQ" name="leak_def_r" class="te_clcik" data-sectionId="teeth_sel" value='LRQ'>-->
					<label for="leak_def_r_LRQ">Lower Right</label>
				</li>
			</ul>
          </div>
          <div class="col-md-6">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="leak_def_r_ULQ" name="leak_def_r" class="te_clcik" data-sectionId="teeth_sel" value='ULQ'>-->
					<label for="leak_def_r_ULQ">Upper Left</label>
				</li>
			</ul>
	        <div class="row">
	          <div class="col-md-12 border_bottomonepx">
				<ul class="modal-ch urq mb0" style="text-align: left;">
					<li class="">
						<input type='checkbox' id="leak_def_tth_21" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='21'>
						<label for="leak_def_tth_21">21</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_22" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='22'>
						<label for="leak_def_tth_22">22</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_23" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='23'>
						<label for="leak_def_tth_23">23</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_24" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='24'>
						<label for="leak_def_tth_24">24</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_25" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='25'>
						<label for="leak_def_tth_25">25</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_26" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='26'>
						<label for="leak_def_tth_26">26</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_27" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='27'>
						<label for="leak_def_tth_27">27</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_28" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='28'>
						<label for="leak_def_tth_28">28</label>
					</li>
				</ul>
	          </div>
          	</div>	
          	<div class="seprater"> </div>
	        <div class="row">
	          <div class="col-md-12">
				<ul class="modal-ch urq mb0" style="text-align: left;">
					<li class="">
						<input type='checkbox' id="leak_def_tth_31" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='31'>
						<label for="leak_def_tth_31">31</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_32" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='32'>
						<label for="leak_def_tth_32">32</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_33" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='33'>
						<label for="leak_def_tth_33">33</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_34" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='34'>
						<label for="leak_def_tth_34">34</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_35" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='35'>
						<label for="leak_def_tth_35">35</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_36" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='36'>
						<label for="leak_def_tth_36">36</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_37" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='37'>
						<label for="leak_def_tth_37">37</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="leak_def_tth_38" class="te_clcik" data-sectionId="teeth_sel" name="leak_def_r" value='38'>
						<label for="leak_def_tth_38">38</label>
					</li>
				</ul>
	          </div>
          	</div>	
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="dental_exam_resto_LLQ" name="dental_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='LLQ'>-->
					<label for="dental_exam_resto_LLQ">Lower Left</label>
				</li>
			</ul>
          </div>
          <!--<div class="col-md-1">
			<ul class="modal-ch">
				<li class="modal_li_full strighttext">
		          	<input type='checkbox' id="dental_exam_resto_lhs" name="dental_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='LHS'>
					<label for="dental_exam_resto_lhs">L<br>H<br>S</label>
				</li>
			</ul>	
          </div>-->
        </div>
       <!-- <div class="row">
          <div class="col-md-12">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<input type='checkbox' id="dental_exam_resto_Lowers" name="dental_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='Lowers'>
					<label for="dental_exam_resto_Lowers">Lowers</label>
				</li>
			</ul>	
          </div>
        </div>-->
      </div>
      <div class="modal-footer">
	
	<button type="button" class="btn cp_cl closebtn each_model_data" id="add_val_demo" data-teethname="Leaking or defective restorations" data-spancls="pat_exam_teeth_2" data-checkedvalid="pat_e_2" data-fieldname="leak_def_r" data-dismiss="modal" aria-label="Close">Add Note</button>
	
      </div>
    </div>
  </div>
</div>
<!-------------Model_4----------------->

<div class="modal fade" id="myModal_4" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header allmodalheading">
		<h5>TSL : Select Teeth</h5>
       <!-- <button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
      </div>
      <div class="modal-body">
        <!--<div class="row">
          <div class="col-md-12">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<input type='checkbox' id="dental_exam_resto_Uppers" name="dental_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='Uppers'>
					<label for="dental_exam_resto_Uppers">Uppers</label>
				</li>
			</ul>	
          </div>
        </div>-->
        <div class="row">
          <!--<div class="col-md-1">
			<ul class="modal-ch">
				<li class="modal_li_full strighttext">
		          	<input type='checkbox' id="dental_exam_resto_rhs" name="dental_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='RHS'>
					<label for="dental_exam_resto_rhs">R<br>H<br>S</label>
				</li>
			</ul>	
          </div>-->
          <div class="col-md-6 border_rightonepx">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="dental_exam_resto_urq" name="dental_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='URQ'>-->
					<label for="dental_exam_resto_urq">Upper Right</label>
				</li>
			</ul>
	        <div class="row">
	          <div class="col-md-12 border_bottomonepx">
				<ul class="modal-ch urq mb0" style="text-align: right;">
					<li class="">
			          	<input type='checkbox' id="tsl_tth_18" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='18'>
						<label for="tsl_tth_18">18</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="tsl_tth_17" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='17'>
						<label for="tsl_tth_17">17</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="tsl_tth_16" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='16'>
						<label for="tsl_tth_16">16</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="tsl_tth_15" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='15'>
						<label for="tsl_tth_15">15</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="tsl_tth_14" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='14'>
						<label for="tsl_tth_14">14</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="tsl_tth_13" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='13'>
						<label for="tsl_tth_13">13</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="tsl_tth_12" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='12'>
						<label for="tsl_tth_12">12</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="tsl_tth_11" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='11'>
						<label for="tsl_tth_11">11</label>
					</li>
				</ul>
	          </div>
          	</div>
          	<div class="seprater"> </div>
	        <div class="row">
	          <div class="col-md-12">
				<ul class="modal-ch urq mb0" style="text-align: right;">
					<li class="">
						<input type='checkbox' id="tsl_tth_48" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='48'>
						<label for="tsl_tth_48">48</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="tsl_tth_47" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='47'>
						<label for="tsl_tth_47">47</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="tsl_tth_46" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='46'>
						<label for="tsl_tth_46">46</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="tsl_tth_45" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='45'>
						<label for="tsl_tth_45">45</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="tsl_tth_44" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='44'>
						<label for="tsl_tth_44">44</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="tsl_tth_43" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='43'>
						<label for="tsl_tth_43">43</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="tsl_tth_42" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='42'>
						<label for="tsl_tth_42">42</label>
					</li><li class="">
			          	<input type='checkbox' id="tsl_tth_41" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='41'>
						<label for="tsl_tth_41">41</label>
					</li>
				</ul>
	          </div>
          	</div>	
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="tsl_tth_fld_LRQ" name="tsl_tth_fld" class="te_clcik" data-sectionId="teeth_sel" value='LRQ'>-->
					<label for="tsl_tth_fld_LRQ">Lower Right</label>
				</li>
			</ul>
          </div>
          <div class="col-md-6">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="tsl_tth_fld_ULQ" name="tsl_tth_fld" class="te_clcik" data-sectionId="teeth_sel" value='ULQ'>-->
					<label for="tsl_tth_fld_ULQ">Upper Left</label>
				</li>
			</ul>
	        <div class="row">
	          <div class="col-md-12 border_bottomonepx">
				<ul class="modal-ch urq mb0" style="text-align: left;">
					<li class="">
						<input type='checkbox' id="tsl_tth_21" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='21'>
						<label for="tsl_tth_21">21</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="tsl_tth_22" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='22'>
						<label for="tsl_tth_22">22</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="tsl_tth_23" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='23'>
						<label for="tsl_tth_23">23</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="tsl_tth_24" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='24'>
						<label for="tsl_tth_24">24</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="tsl_tth_25" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='25'>
						<label for="tsl_tth_25">25</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="tsl_tth_26" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='26'>
						<label for="tsl_tth_26">26</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="tsl_tth_27" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='27'>
						<label for="tsl_tth_27">27</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="tsl_tth_28" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='28'>
						<label for="tsl_tth_28">28</label>
					</li>
				</ul>
	          </div>
          	</div>	
          	<div class="seprater"> </div>
	        <div class="row">
	          <div class="col-md-12">
				<ul class="modal-ch urq mb0" style="text-align: left;">
					<li class="">
						<input type='checkbox' id="tsl_tth_31" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='31'>
						<label for="tsl_tth_31">31</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="tsl_tth_32" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='32'>
						<label for="tsl_tth_32">32</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="tsl_tth_33" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='33'>
						<label for="tsl_tth_33">33</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="tsl_tth_34" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='34'>
						<label for="tsl_tth_34">34</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="tsl_tth_35" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='35'>
						<label for="tsl_tth_35">35</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="tsl_tth_36" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='36'>
						<label for="tsl_tth_36">36</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="tsl_tth_37" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='37'>
						<label for="tsl_tth_37">37</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="tsl_tth_38" class="te_clcik" data-sectionId="teeth_sel" name="tsl_tth_fld" value='38'>
						<label for="tsl_tth_38">38</label>
					</li>
				</ul>
	          </div>
          	</div>	
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="dental_exam_resto_LLQ" name="dental_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='LLQ'>-->
					<label for="dental_exam_resto_LLQ">Lower Left</label>
				</li>
			</ul>
          </div>
          <!--<div class="col-md-1">
			<ul class="modal-ch">
				<li class="modal_li_full strighttext">
		          	<input type='checkbox' id="dental_exam_resto_lhs" name="dental_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='LHS'>
					<label for="dental_exam_resto_lhs">L<br>H<br>S</label>
				</li>
			</ul>	
          </div>-->
        </div>
       <!-- <div class="row">
          <div class="col-md-12">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<input type='checkbox' id="dental_exam_resto_Lowers" name="dental_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='Lowers'>
					<label for="dental_exam_resto_Lowers">Lowers</label>
				</li>
			</ul>	
          </div>
        </div>-->
      </div>
      <div class="modal-footer">
	
	<button type="button" class="btn cp_cl closebtn each_model_data" id="add_val_demo" data-teethname="TSL" data-spancls="pat_exam_teeth_3" data-checkedvalid="pat_e_3" data-fieldname="tsl_tth_fld" data-dismiss="modal" aria-label="Close">Add Note</button>
	
      </div>
    </div>
  </div>
</div>
<!-------------Model_5----------------->

<div class="modal fade" id="myModal_5" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header allmodalheading">
		<h5>Mobility : Select Teeth</h5>
       <!-- <button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
      </div>
      <div class="modal-body">
        <!--<div class="row">
          <div class="col-md-12">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<input type='checkbox' id="dental_exam_resto_Uppers" name="dental_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='Uppers'>
					<label for="dental_exam_resto_Uppers">Uppers</label>
				</li>
			</ul>	
          </div>
        </div>-->
        <div class="row">
          <!--<div class="col-md-1">
			<ul class="modal-ch">
				<li class="modal_li_full strighttext">
		          	<input type='checkbox' id="dental_exam_resto_rhs" name="dental_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='RHS'>
					<label for="dental_exam_resto_rhs">R<br>H<br>S</label>
				</li>
			</ul>	
          </div>-->
          <div class="col-md-6 border_rightonepx">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="dental_exam_resto_urq" name="dental_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='URQ'>-->
					<label for="dental_exam_resto_urq">Upper Right</label>
				</li>
			</ul>
	        <div class="row">
	          <div class="col-md-12 border_bottomonepx">
				<ul class="modal-ch urq mb0" style="text-align: right;">
					<li class="">
			          	<input type='checkbox' id="mob_tth_18" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='18'>
						<label for="mob_tth_18">18</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mob_tth_17" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='17'>
						<label for="mob_tth_17">17</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mob_tth_16" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='16'>
						<label for="mob_tth_16">16</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mob_tth_15" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='15'>
						<label for="mob_tth_15">15</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mob_tth_14" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='14'>
						<label for="mob_tth_14">14</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mob_tth_13" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='13'>
						<label for="mob_tth_13">13</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mob_tth_12" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='12'>
						<label for="mob_tth_12">12</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mob_tth_11" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='11'>
						<label for="mob_tth_11">11</label>
					</li>
				</ul>
	          </div>
          	</div>
          	<div class="seprater"> </div>
	        <div class="row">
	          <div class="col-md-12">
				<ul class="modal-ch urq mb0" style="text-align: right;">
					<li class="">
						<input type='checkbox' id="mob_tth_48" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='48'>
						<label for="mob_tth_48">48</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mob_tth_47" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='47'>
						<label for="mob_tth_47">47</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mob_tth_46" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='46'>
						<label for="mob_tth_46">46</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mob_tth_45" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='45'>
						<label for="mob_tth_45">45</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mob_tth_44" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='44'>
						<label for="mob_tth_44">44</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mob_tth_43" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='43'>
						<label for="mob_tth_43">43</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mob_tth_42" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='42'>
						<label for="mob_tth_42">42</label>
					</li><li class="">
			          	<input type='checkbox' id="mob_tth_41" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='41'>
						<label for="mob_tth_41">41</label>
					</li>
				</ul>
	          </div>
          	</div>	
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="mob_pt_ex_LRQ" name="mob_pt_ex" class="te_clcik" data-sectionId="teeth_sel" value='LRQ'>-->
					<label for="mob_pt_ex_LRQ">Lower Right</label>
				</li>
			</ul>
          </div>
          <div class="col-md-6">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="mob_pt_ex_ULQ" name="mob_pt_ex" class="te_clcik" data-sectionId="teeth_sel" value='ULQ'>-->
					<label for="mob_pt_ex_ULQ">Upper Left</label>
				</li>
			</ul>
	        <div class="row">
	          <div class="col-md-12 border_bottomonepx">
				<ul class="modal-ch urq mb0" style="text-align: left;">
					<li class="">
						<input type='checkbox' id="mob_tth_21" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='21'>
						<label for="mob_tth_21">21</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mob_tth_22" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='22'>
						<label for="mob_tth_22">22</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mob_tth_23" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='23'>
						<label for="mob_tth_23">23</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mob_tth_24" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='24'>
						<label for="mob_tth_24">24</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mob_tth_25" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='25'>
						<label for="mob_tth_25">25</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mob_tth_26" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='26'>
						<label for="mob_tth_26">26</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mob_tth_27" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='27'>
						<label for="mob_tth_27">27</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mob_tth_28" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='28'>
						<label for="mob_tth_28">28</label>
					</li>
				</ul>
	          </div>
          	</div>	
          	<div class="seprater"> </div>
	        <div class="row">
	          <div class="col-md-12">
				<ul class="modal-ch urq mb0" style="text-align: left;">
					<li class="">
						<input type='checkbox' id="mob_tth_31" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='31'>
						<label for="mob_tth_31">31</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mob_tth_32" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='32'>
						<label for="mob_tth_32">32</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mob_tth_33" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='33'>
						<label for="mob_tth_33">33</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mob_tth_34" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='34'>
						<label for="mob_tth_34">34</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mob_tth_35" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='35'>
						<label for="mob_tth_35">35</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mob_tth_36" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='36'>
						<label for="mob_tth_36">36</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mob_tth_37" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='37'>
						<label for="mob_tth_37">37</label>
					</li>
					<li class="">
			          	<input type='checkbox' id="mob_tth_38" class="te_clcik" data-sectionId="teeth_sel" name="mob_pt_ex" value='38'>
						<label for="mob_tth_38">38</label>
					</li>
				</ul>
	          </div>
          	</div>	
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<!--<input type='checkbox' id="dental_exam_resto_LLQ" name="dental_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='LLQ'>-->
					<label for="dental_exam_resto_LLQ">Lower Left</label>
				</li>
			</ul>
          </div>
          <!--<div class="col-md-1">
			<ul class="modal-ch">
				<li class="modal_li_full strighttext">
		          	<input type='checkbox' id="dental_exam_resto_lhs" name="dental_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='LHS'>
					<label for="dental_exam_resto_lhs">L<br>H<br>S</label>
				</li>
			</ul>	
          </div>-->
        </div>
       <!-- <div class="row">
          <div class="col-md-12">
			<ul class="modal-ch">
				<li class="modal_li_full">
		          	<input type='checkbox' id="dental_exam_resto_Lowers" name="dental_exam_resto" class="te_clcik" data-sectionId="teeth_sel" value='Lowers'>
					<label for="dental_exam_resto_Lowers">Lowers</label>
				</li>
			</ul>	
          </div>
        </div>-->
      </div>
      <div class="modal-footer">
	
	<button type="button" class="btn cp_cl closebtn each_model_data" id="add_val_demo" data-teethname="Leaking or defective restorations" data-spancls="pat_exam_teeth_4" data-checkedvalid="pat_e_4" data-fieldname="mob_pt_ex" data-dismiss="modal" aria-label="Close">Add Note</button>
	
      </div>
    </div>
  </div>
</div>