<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "note_making";

//navroop.singhthiara@pacificsmiles.com.au