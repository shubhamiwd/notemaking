<!--------Modal_1 -------->

<div class="modal fade" id="myModal_1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
		<div class="modal-header">
			<!-- <button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
		</div>
		<div class="modal-body">
			<!--<div class="row">
			  <div class="col-md-12">
				<ul class="modal-ch">
					<li class="modal_li_full">
						<input type='checkbox' id="Uppers" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='Uppers'>
						<label for="Uppers">Uppers</label>
					</li>
				</ul>	
			  </div>
			</div>-->
			<div class="row">
			  <!--<div class="col-md-1">
				<ul class="modal-ch">
					<li class="modal_li_full strighttext">
						<input type='checkbox' id="rhs" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='RHS'>
						<label for="rhs">R<br>H<br>S</label>
					</li>
				</ul>	
			  </div>-->
				<div class="col-md-5 border_rightonepx">
					<ul class="modal-ch">
						<li class="modal_li_full">
							<!--<input type='checkbox' id="urq" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='URQ'>-->
							<label for="urq">Upper Right</label>
						</li>
					</ul>
					<div class="row">
						<div class="col-md-12 border_bottomonepx">
							<ul class="modal-ch urq mb0" style="text-align: right;">
								<li class="">
									<input type='checkbox' id="Caries_18" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='18'>
									<label for="Caries_18">18</label>
								</li>
								<li class="">
									<input type='checkbox' id="Caries_17" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='17'>
									<label for="Caries_17">17</label>
								</li>
								<li class="">
									<input type='checkbox' id="Caries_16" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='16'>
									<label for="Caries_16">16</label>
								</li>
								<li class="">
									<input type='checkbox' id="Caries_15" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='15'>
									<label for="Caries_15">15</label>
								</li>
								<li class="">
									<input type='checkbox' id="Caries_14" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='14'>
									<label for="Caries_14">14</label>
								</li>
								<li class="">
									<input type='checkbox' id="Caries_13" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='13'>
									<label for="Caries_13">13</label>
								</li>
								<li class="">
									<input type='checkbox' id="Caries_12" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='12'>
									<label for="Caries_12">12</label>
								</li>
								<li class="">
									<input type='checkbox' id="Caries_11" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='11'>
									<label for="Caries_11">11</label>
								</li>
							</ul>
						</div>
					</div>
					<div class="seprater"> </div>
					<div class="row">
						<div class="col-md-12">
							<ul class="modal-ch urq mb0" style="text-align: right;">
								<li class="">
									<input type='checkbox' id="Caries_48" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='48'>
									<label for="Caries_48">48</label>
								</li>
								<li class="">
									<input type='checkbox' id="Caries_47" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='47'>
									<label for="Caries_47">47</label>
								</li>
								<li class="">
									<input type='checkbox' id="Caries_46" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='46'>
									<label for="Caries_46">46</label>
								</li>
								<li class="">
									<input type='checkbox' id="Caries_45" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='45'>
									<label for="Caries_45">45</label>
								</li>
								<li class="">
									<input type='checkbox' id="Caries_44" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='44'>
									<label for="Caries_44">44</label>
								</li>
								<li class="">
									<input type='checkbox' id="Caries_43" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='43'>
									<label for="Caries_43">43</label>
								</li>
								<li class="">
									<input type='checkbox' id="Caries_42" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='42'>
									<label for="Caries_42">42</label>
								</li><li class="">
									<input type='checkbox' id="Caries_41" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='41'>
									<label for="Caries_41">41</label>
								</li>

							</ul>
						</div>
					</div>	
					<ul class="modal-ch">
						<li class="modal_li_full">
							<!--<input type='checkbox' id="LRQ" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='LRQ'>-->
							<label for="ULQ">Lower Right</label>
						</li>
					</ul>
				</div>
				<div class="col-md-5">
					<ul class="modal-ch">
						<li class="modal_li_full">
							<!--<input type='checkbox' id="ULQ" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='ULQ'>-->
							<label for="ULQ">Upper Left</label>
						</li>
					</ul>
					<div class="row">
						<div class="col-md-12 border_bottomonepx">
							<ul class="modal-ch urq mb0" style="text-align: left;">
								<li class="">
									<input type='checkbox' id="Caries_21" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='21'>
									<label for="Caries_21">21</label>
								</li>
								<li class="">
									<input type='checkbox' id="Caries_22" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='22'>
									<label for="Caries_22">22</label>
								</li>
								<li class="">
									<input type='checkbox' id="Caries_23" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='23'>
									<label for="Caries_23">23</label>
								</li>
								<li class="">
									<input type='checkbox' id="Caries_24" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='24'>
									<label for="Caries_24">24</label>
								</li>
								<li class="">
									<input type='checkbox' id="Caries_25" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='25'>
									<label for="Caries_25">25</label>
								</li>
								<li class="">
									<input type='checkbox' id="Caries_26" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='26'>
									<label for="Caries_26">26</label>
								</li>
								<li class="">
									<input type='checkbox' id="Caries_27" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='27'>
									<label for="Caries_27">27</label>
								</li>
								<li class="">
									<input type='checkbox' id="Caries_28" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='28'>
									<label for="Caries_28">28</label>
								</li>
							</ul>
					  </div>
					</div>	
					<div class="seprater"> </div>
					<div class="row">
						<div class="col-md-12">
							<ul class="modal-ch urq mb0" style="text-align: left;">
								<li class="">
									<input type='checkbox' id="Caries_31" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='31'>
									<label for="Caries_31">31</label>
								</li>
								<li class="">
									<input type='checkbox' id="Caries_32" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='32'>
									<label for="Caries_32">32</label>
								</li>
								<li class="">
									<input type='checkbox' id="Caries_33" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='33'>
									<label for="Caries_33">33</label>
								</li>
								<li class="">
									<input type='checkbox' id="Caries_34" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='34'>
									<label for="Caries_34">34</label>
								</li>
								<li class="">
									<input type='checkbox' id="Caries_35" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='35'>
									<label for="Caries_35">35</label>
								</li>
								<li class="">
									<input type='checkbox' id="Caries_36" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='36'>
									<label for="Caries_36">36</label>
								</li>
								<li class="">
									<input type='checkbox' id="Caries_37" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='37'>
									<label for="Caries_37">37</label>
								</li>
								<li class="">
									<input type='checkbox' id="Caries_38" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='38'>
									<label for="Caries_38">38</label>
								</li>
							</ul>
						</div>
					</div>	
					<ul class="modal-ch">
						<li class="modal_li_full">
							<!--<input type='checkbox' id="LLQ" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='LLQ'>-->
							<label for="LLQ">Lower Left</label>
						</li>
					</ul>
				</div>
				 <!-- <div class="col-md-1">
					<ul class="modal-ch">
						<li class="modal_li_full strighttext">
							<input type='checkbox' id="lhs" class="te_clcik" data-sectionId="teeth_sel" value='LHS'>
							<label for="lhs">L<br>H<br>S</label>
						</li>
					</ul>	
				  </div>-->
			</div>
				<!--<div class="row">
				  <div class="col-md-12">
					<ul class="modal-ch">
						<li class="modal_li_full">
							<input type='checkbox' id="Lowers" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='Lowers'>
							<label for="Lowers">Lowers</label>
						</li>
					</ul>	
				  </div>
				</div>-->
		</div>
		<div class="modal-footer">
			<button type="button" class="btn cp_cl closebtn each_model_data" id="" data-teethname="Caries" data-spancls="ipr_spn" data-checkedvalid="ipr_ipt" data-clicked_1="co_option_sel" data-fieldname="dental_exam_caries" data-dismiss="modal" aria-label="Close">Add Note</button>
		</div>
	</div>
  </div>
</div>
<!--------Modal_2 -------->

<div class="modal fade" id="myModal_2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
		<div class="modal-header">
			<!-- <button type="button" class="closebtn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
		</div>
		<div class="modal-body">
			<!--<div class="row">
			  <div class="col-md-12">
				<ul class="modal-ch">
					<li class="modal_li_full">
						<input type='checkbox' id="Uppers" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='Uppers'>
						<label for="Uppers">Uppers</label>
					</li>
				</ul>	
			  </div>
			</div>-->
			<div class="row">
			  <!--<div class="col-md-1">
				<ul class="modal-ch">
					<li class="modal_li_full strighttext">
						<input type='checkbox' id="rhs" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='RHS'>
						<label for="rhs">R<br>H<br>S</label>
					</li>
				</ul>	
			  </div>-->
				<div class="col-md-5 border_rightonepx">
					<ul class="modal-ch">
						<li class="modal_li_full">
							<!--<input type='checkbox' id="urq" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='URQ'>-->
							<label for="urq">Upper Right</label>
						</li>
					</ul>
					<div class="row">
						<div class="col-md-12 border_bottomonepx">
							<ul class="modal-ch urq mb0" style="text-align: right;">
								<li class="">
									<input type='checkbox' id="atch_1" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='18'>
									<label for="atch_1">18</label>
								</li>
								<li class="">
									<input type='checkbox' id="atch_2" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='17'>
									<label for="atch_2">17</label>
								</li>
								<li class="">
									<input type='checkbox' id="atch_3" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='16'>
									<label for="atch_3">16</label>
								</li>
								<li class="">
									<input type='checkbox' id="atch_4" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='15'>
									<label for="atch_4">15</label>
								</li>
								<li class="">
									<input type='checkbox' id="atch_5" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='14'>
									<label for="atch_5">14</label>
								</li>
								<li class="">
									<input type='checkbox' id="atch_6" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='13'>
									<label for="atch_6">13</label>
								</li>
								<li class="">
									<input type='checkbox' id="atch_7" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='12'>
									<label for="atch_7">12</label>
								</li>
								<li class="">
									<input type='checkbox' id="atch_8" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='11'>
									<label for="atch_8">11</label>
								</li>
							</ul>
						</div>
					</div>
					<div class="seprater"> </div>
					<div class="row">
						<div class="col-md-12">
							<ul class="modal-ch urq mb0" style="text-align: right;">
								<li class="">
									<input type='checkbox' id="atch_9" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='48'>
									<label for="atch_9">48</label>
								</li>
								<li class="">
									<input type='checkbox' id="atch_10" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='47'>
									<label for="atch_10">47</label>
								</li>
								<li class="">
									<input type='checkbox' id="atch_11" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='46'>
									<label for="atch_11">46</label>
								</li>
								<li class="">
									<input type='checkbox' id="atch_12" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='45'>
									<label for="atch_12">45</label>
								</li>
								<li class="">
									<input type='checkbox' id="atch_13" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='44'>
									<label for="atch_13">44</label>
								</li>
								<li class="">
									<input type='checkbox' id="atch_14" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='43'>
									<label for="atch_14">43</label>
								</li>
								<li class="">
									<input type='checkbox' id="atch_15" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='42'>
									<label for="atch_15">42</label>
								</li><li class="">
									<input type='checkbox' id="atch_16" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='41'>
									<label for="atch_16">41</label>
								</li>

							</ul>
						</div>
					</div>	
					<ul class="modal-ch">
						<li class="modal_li_full">
							<!--<input type='checkbox' id="LRQ" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='LRQ'>-->
							<label for="ULQ">Lower Right</label>
						</li>
					</ul>
				</div>
				<div class="col-md-5">
					<ul class="modal-ch">
						<li class="modal_li_full">
							<!--<input type='checkbox' id="ULQ" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='ULQ'>-->
							<label for="ULQ">Upper Left</label>
						</li>
					</ul>
					<div class="row">
						<div class="col-md-12 border_bottomonepx">
							<ul class="modal-ch urq mb0" style="text-align: left;">
								<li class="">
									<input type='checkbox' id="atch_17" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='21'>
									<label for="atch_17">21</label>
								</li>
								<li class="">
									<input type='checkbox' id="atch_18" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='22'>
									<label for="atch_18">22</label>
								</li>
								<li class="">
									<input type='checkbox' id="atch_19" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='23'>
									<label for="atch_19">23</label>
								</li>
								<li class="">
									<input type='checkbox' id="atch_20" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='24'>
									<label for="atch_20">24</label>
								</li>
								<li class="">
									<input type='checkbox' id="atch_21" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='25'>
									<label for="atch_21">25</label>
								</li>
								<li class="">
									<input type='checkbox' id="atch_22" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='26'>
									<label for="atch_22">26</label>
								</li>
								<li class="">
									<input type='checkbox' id="atch_23" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='27'>
									<label for="atch_23">27</label>
								</li>
								<li class="">
									<input type='checkbox' id="atch_24" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='28'>
									<label for="atch_24">28</label>
								</li>
							</ul>
					  </div>
					</div>	
					<div class="seprater"> </div>
					<div class="row">
						<div class="col-md-12">
							<ul class="modal-ch urq mb0" style="text-align: left;">
								<li class="">
									<input type='checkbox' id="atch_25" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='31'>
									<label for="atch_25">31</label>
								</li>
								<li class="">
									<input type='checkbox' id="atch_26" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='32'>
									<label for="atch_26">32</label>
								</li>
								<li class="">
									<input type='checkbox' id="atch_32" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='33'>
									<label for="atch_32">33</label>
								</li>
								<li class="">
									<input type='checkbox' id="atch_27" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='34'>
									<label for="atch_27">34</label>
								</li>
								<li class="">
									<input type='checkbox' id="atch_28" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='35'>
									<label for="atch_28">35</label>
								</li>
								<li class="">
									<input type='checkbox' id="atch_29" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='36'>
									<label for="atch_29">36</label>
								</li>
								<li class="">
									<input type='checkbox' id="atch_30" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='37'>
									<label for="atch_30">37</label>
								</li>
								<li class="">
									<input type='checkbox' id="atch_31" class="te_clcik" data-sectionId="teeth_sel" name="attch_tth" value='38'>
									<label for="atch_31">38</label>
								</li>
							</ul>
						</div>
					</div>	
					<ul class="modal-ch">
						<li class="modal_li_full">
							<!--<input type='checkbox' id="LLQ" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='LLQ'>-->
							<label for="LLQ">Lower Left</label>
						</li>
					</ul>
				</div>
				 <!-- <div class="col-md-1">
					<ul class="modal-ch">
						<li class="modal_li_full strighttext">
							<input type='checkbox' id="lhs" class="te_clcik" data-sectionId="teeth_sel" value='LHS'>
							<label for="lhs">L<br>H<br>S</label>
						</li>
					</ul>	
				  </div>-->
			</div>
				<!--<div class="row">
				  <div class="col-md-12">
					<ul class="modal-ch">
						<li class="modal_li_full">
							<input type='checkbox' id="Lowers" class="te_clcik" data-sectionId="teeth_sel" name="dental_exam_caries" value='Lowers'>
							<label for="Lowers">Lowers</label>
						</li>
					</ul>	
				  </div>
				</div>-->
		</div>
		<div class="modal-footer">
			<button type="button" class="btn cp_cl closebtn each_model_data" id="" data-teethname="Caries" data-spancls="attche" data-checkedvalid="attch_shw" data-clicked_1="co_option_sel" data-fieldname="attch_tth" data-dismiss="modal" aria-label="Close">Add Note</button>
		</div>
	</div>
  </div>
</div>