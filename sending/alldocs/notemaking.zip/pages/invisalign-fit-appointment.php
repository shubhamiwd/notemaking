<?php 
/*
Template Name: Invisalign Fit Appointment.
*/

include '../templates/header-v2.php';
include '../models/invisalign-fit-appointment.php';
?>
<div class="container" id="checkbox-container">
	<div class="tem_title">
		<h2>Invisalign Fit</h2>
	</div>
	<form onclick="">
		<div class="main-section">
			<div class="mtnegtive">
				<div class="main-sec">
					<div class="main-sec-in">
						<h3>Invisalign Fit Appointment</h3>
							<input type="hidden" name="heading" id="" value="">
							<input type="hidden" name="heading" id="" value="----------- Invisalign Fit Appointment ------------">
							<input type="hidden" name="heading" id="" value="">
						<div class="txt-lbl">
							<p>MH:</p>
							<ul class="rbtn">
								<li>
									<input type='radio' id="ifa_1" name='ifa' data-fieddata="Patient" value='No Changes'>
									<label for="ifa_1">No Changes</label>
								</li>
								<li>
									<input type='radio' id="ifa_2" name='ifa' data-fieddata="Patient" value='Other'>
									<label for="ifa_2">Other</label>
								</li>
							</ul>
						</div>
						<div class="inputcss">
							<!-- <input type='text' name='Dentist' id="a2" data-fieddata="Dentist" value='Dentist: -->
							<input type='text' name='Nurse' id="a3" data-fieddata="Nurse" value='Patient is happy with clin-check: '>
						</div>
						<div class="inputcss">
							<!-- <input type='text' name='Dentist' id="a2" data-fieddata="Dentist" value='Dentist: -->
							<input type='text' name='Nurse' id="a3" data-fieddata="Nurse" value='Pateint has been consented about Invisalign treatment and other alternatives: '>
						</div>
						<div class="inputcss">
							<!-- <input type='text' name='Dentist' id="a2" data-fieddata="Dentist" value='Dentist: -->
							<input type='text' name='Nurse' id="a3" data-fieddata="Nurse" value='Aware of the nature if Invisalign and its featues including: IPR, attachemnts and need for compliance: '>
						</div>
						
					</div>
				</div>
			</div>
			<div class="main-sec">
				<div class="main-sec-in">
					<h3>IPR:</h3>
						<input type="hidden" name="heading" id="" value="">
						<input type="hidden" name="heading" id="" value="----------- IPR: ------------">
						<input type="hidden" name="heading" id="" value="">
					<div class="txt-lbl">
						<ul class="rbtn">
							<li>
								<input type='radio' id="ipr_1" name='ipr' data-fieddata="Patient" value='Nil'>
								<label for="ipr_1">Nil</label>
							</li>
						</ul>
						<div class=""><p><span class="ipr_spn"></span></p>
						<ul class="rbtn">
							<li>
								<div data-toggle="modal" data-target="#myModal_1" class="sel_lnk">Select Teeth<i class="fas fa-external-link-alt"></i></div>
							</li>
						</ul>
						</div>
						<div class="carries">
							<input type="hidden" name="co_sel" id="ipr_ipt" value="">
							<!--<label for="" class="mt20">Caries: <span class="co_sel_teeth"></span></label>-->
						</div>
						<div class="inputcss">
							<input type="text" name="med_notes" value="" placeholder="Enter notes here...">
						</div>
					</div>
					
				</div>
			</div>
			<div class="main-sec">
				<div class="main-sec-in">
					<h3>Attachments:</h3>
						<input type="hidden" name="heading" id="" value="">
						<input type="hidden" name="heading" id="" value="----------- Attachments: ------------">
						<input type="hidden" name="heading" id="" value="">
					<div class="txt-lbl">
						<ul class="rbtn">
							<li>
								<input type='radio' id="ipr_1" name='ipr' data-fieddata="Patient" value='Nil'>
								<label for="ipr_1">Nil</label>
							</li>
						</ul>
						<div class=""><p><span class="attche"></span></p>
						<ul class="rbtn">
							<li>
								<div data-toggle="modal" data-target="#myModal_2" class="sel_lnk">Select Teeth<i class="fas fa-external-link-alt"></i></div>
							</li>
						</ul>
						</div>
						<div class="carries">
							<input type="hidden" name="ipr_hdn" id="attch_shw" value="">
							<!--<label for="" class="mt20">Caries: <span class="co_sel_teeth"></span></label>-->
						</div>
					</div>
					<div class="txt-lbl">
						<ul class="rbtn">
							<li>
								<input type='radio' id="ipr_2" name='ipr1' data-fieddata="Patient" value='Flowable'>
								<label for="ipr_2">Flowable</label>
							</li>
							<li>
								<input type='radio' id="ipr_3" name='ipr1' data-fieddata="Patient" value='Restroative'>
								<label for="ipr_3">Restroative</label>
							</li>
						</ul>
					</div>
					<div class="txt-lbl">
						<ul class="rbtn">
							<li>
								<input type='radio' id="ipr_4" name='ipr2' data-fieddata="Patient" value='A1'>
								<label for="ipr_4">A1</label>
							</li>
							<li>
								<input type='radio' id="ipr_5" name='ipr2' data-fieddata="Patient" value='A2'>
								<label for="ipr_5">A2</label>
							</li>
							<li>
								<input type='radio' id="ipr_6" name='ipr2' data-fieddata="Patient" value='A3'>
								<label for="ipr_6">A3</label>
							</li>
							<li>
								<input type='radio' id="ipr_7" name='ipr2' data-fieddata="Patient" value='A3.5'>
								<label for="ipr_7">A3.5</label>
							</li>
							<li>
								<input type='radio' id="ipr_8" name='ipr2' data-fieddata="Patient" value='B1'>
								<label for="ipr_8">B1</label>
							</li>
							<li>
								<input type='radio' id="ipr_9" name='ipr2' data-fieddata="Patient" value='B2'>
								<label for="ipr_9">B2</label>
							</li>
							<li>
								<input type='radio' id="ipr_10" name='ipr2' data-fieddata="Patient" value='B3'>
								<label for="ipr_10">B3</label>
							</li>
							<li>
								<input type='radio' id="ipr_11" name='ipr2' data-fieddata="Patient" value='C1'>
								<label for="ipr_11">C1</label>
							</li>
							<li>
								<input type='radio' id="ipr_12" name='ipr2' data-fieddata="Patient" value='C2'>
								<label for="ipr_12">C2</label>
							</li>
							<li>
								<input type='radio' id="ipr_13" name='ipr2' data-fieddata="Patient" value='C3'>
								<label for="ipr_13">C3</label>
							</li>
							<li>
								<input type='radio' id="ipr_14" name='D1' data-fieddata="Patient" value='D1'>
								<label for="ipr_14">D1</label>
							</li>
							<li>
								<input type='radio' id="ipr_15" name='D2' data-fieddata="Patient" value='D2'>
								<label for="ipr_15">D2</label>
							</li>
							<li>
								<input type='radio' id="ipr_16" name='D3' data-fieddata="Patient" value='D3'>
								<label for="ipr_16">D3</label>
							</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="main-sec">
				<div class="main-sec-in">
					<h3>Aligners</h3>
						<input type="hidden" name="heading" id="" value="">
						<input type="hidden" name="heading" id="" value="----------- Aligners ------------">
						<input type="hidden" name="heading" id="" value="">
					<div class="inputcss">
						<p>Aligners fitted - fitting well no issues pt can take in and out</p>
					</div>
					<div class="txt-lbl">
							<p>Issued with aligner numbers:</p>
							<ul class="rbtn">
								<li>
									<select name="sel1" id="aligner-sel">
										<option value="" disabled selected>Select your option</option>
										<option value="1">1</option>
										<option value="2">2</option>
										<option value="3">3</option>
										<option value="4">4</option>
										<option value="5">5</option>
										<option value="6">6</option>
										<option value="7">7</option>
										<option value="8">8</option>
										<option value="9">9</option>
										<option value="10">10</option>
										<option value="11">11</option>
										<option value="12">12</option>
										<option value="13">13</option>
										<option value="14">14</option>
										<option value="15">15</option>
										<option value="16">16</option>
										<option value="17">17</option>
										<option value="18">18</option>
										<option value="19">19</option>
										<option value="20">20</option>
										<option value="21">21</option>
										<option value="22">22</option>
										<option value="23">23</option>
										<option value="24">24</option>
										<option value="other">Other</option>
									</select>
								</li>
							</ul>
							<p>to</p>
							<ul class="rbtn">
								<li>
									<select name="sel1" id="aligner-sel">
										<option value="" disabled selected>Select your option</option>
										<option value="1">1</option>
										<option value="2">2</option>
										<option value="3">3</option>
										<option value="4">4</option>
										<option value="5">5</option>
										<option value="6">6</option>
										<option value="7">7</option>
										<option value="8">8</option>
										<option value="9">9</option>
										<option value="10">10</option>
										<option value="11">11</option>
										<option value="12">12</option>
										<option value="13">13</option>
										<option value="14">14</option>
										<option value="15">15</option>
										<option value="16">16</option>
										<option value="17">17</option>
										<option value="18">18</option>
										<option value="19">19</option>
										<option value="20">20</option>
										<option value="21">21</option>
										<option value="22">22</option>
										<option value="23">23</option>
										<option value="24">24</option>
										<option value="other">Other</option>
									</select>
								</li>
							</ul>
						</div>
				</div>
			</div>
			<div class="main-sec">
				<div class="main-sec-in">
					<h3>Instructions</h3>
						<input type="hidden" name="heading" id="" value="">
						<input type="hidden" name="heading" id="" value="----------- Instructions ------------">
						<input type="hidden" name="heading" id="" value="">
					<div class="inputcss">
						<p>Full time wear (22hrs/day) apart from cleaning and eating</p>
						<p>Chewies to help seating</p>
						<p>Keep aligners in the box at all times when not wearing</p>
						<p>No eating or dinking with the aligners in except for water</p>
						<p>Pracice speaking to get used to the sensation</p>
						<p>Keep old aligners safe in case of loss of current one</p>
					</div>
					<div class="txt-lbl">
							<ul class="rbtn">
								<li>
									<input type='radio' id="inst_1" name='inst' data-fieddata="Patient" value='1'>
									<label for="inst_1">1</label>
								</li>
								<li>
									<input type='radio' id="inst_2" name='inst' data-fieddata="Patient" value='1'>
									<label for="inst_2">2</label>
								</li>
								<li>
									<input type='radio' id="inst_3" name='inst' data-fieddata="Patient" value='1'>
									<label for="inst_3">3</label>
								</li>
								<li>
									weekly chnages
								</li>
							</ul>
					</div>
				</div>
			</div>
			<div class="main-sec">
				<div class="main-sec-in">
					<h3>Next appointment:</h3>
						<input type="hidden" name="heading" id="" value="">
						<input type="hidden" name="heading" id="" value="----------- Next appointment: ------------">
					<div class="txt-lbl">
						<ul class="rbtn">
							<li>
								<input type='radio' id="napt_1" name='napt' data-fieddata="Patient" value='1'>
								<label for="napt_1">1</label>
							</li>
							<li>
								<input type='radio' id="napt_2" name='napt' data-fieddata="Patient" value='2'>
								<label for="napt_2">2</label>
							</li>
							<li>
								<input type='radio' id="napt_3" name='napt' data-fieddata="Patient" value='3'>
								<label for="napt_3">3</label>
							</li>
							<li>
								<input type='radio' id="napt_4" name='napt' data-fieddata="Patient" value='4'>
								<label for="napt_4">4</label>
							</li>
							<li>
								<input type='radio' id="napt_5" name='napt' data-fieddata="Patient" value='5'>
								<label for="napt_5">5</label>
							</li>
							<li>
								<input type='radio' id="napt_6" name='napt' data-fieddata="Patient" value='6'>
								<label for="napt_6">6</label>
							</li>
							<li>
								<input type='radio' id="napt_7" name='napt' data-fieddata="Patient" value='7'>
								<label for="napt_7">7</label>
							</li>
							<li>
								<input type='radio' id="napt_8" name='napt' data-fieddata="Patient" value='8'>
								<label for="napt_8">8</label>
							</li>
							<li>
								<input type='radio' id="napt_9" name='napt' data-fieddata="Patient" value='9'>
								<label for="napt_9">9</label>
							</li>
							<li>
								<input type='radio' id="napt_10" name='napt' data-fieddata="Patient" value='10'>
								<label for="napt_10">10</label>
							</li>
							<li>
								<input type='radio' id="napt_11" name='napt' data-fieddata="Patient" value='other'>
								<label for="napt_11">other</label>
							</li>
							<li>
								weeks
							</li>
						</ul>
					</div>
					<div class="inputcss">
							<input type="text" name="med_notes" value="" placeholder="Enter notes here...">
					</div>
				</div>
			</div>
			<div class="txt_cpd"><p>Text Copied</p></div>
		</div>
	</div>
<?php //} ?>
<!-------End_Model--------->
			<div class="Clipboard_btn">
				<button class='copy cp_cl' onclick="storage_data();">Copy To Clipboard</button>
			</div>
		</form>
		<textarea id='copy' class="display_none"></textarea>
</div>

<?php include '../templates/footer.php'; ?>
<script>
$(document).ready(function(){
	$(".copy").click(function(){
			$(".txt_cpd").fadeIn(1000, function(){
				$(".txt_cpd").delay(2000).fadeOut(5000);
			});
	});
});
</script>
<style>
select#aligner-sel {
    background: rgba(0, 0, 0, 0) linear-gradient(135deg, rgb(20, 162, 177) 0%, rgb(4, 106, 180) 100%) repeat scroll 0% 0%;
    color: #fff;
    border: #046ab4;
    padding: 10px 24px;
    margin-right: 10px;
    border-radius: 8px;
}
#aligner-sel option {
    background: #0671b3;
}
</style>

<style>
.txt_cpd {
    width:100%;
    display: none;
	float:left;
	position: absolute;
    bottom: 20px;
    left: 0;
    right: 0;
}
.main-section{
	position:relative;
}
.txt_cpd p{
	text-align: center;
    margin: 0px auto;
    background: #28a745c2;
    width: 14%;
    color: #fff;
    padding: 5px 10px;
    border-radius: 50px;
}
</style>
